# Game Shelf Extension - Auto Logger

Automatically log your daily puzzle games to Game Shelf!

## 🚀 Easy Installation

### Mac Users
1. Unzip this file
2. **For Chrome/Edge/Brave**: Double-click `install-chrome-mac.command`
3. **For Safari**: Double-click `install-safari.command`

### Windows Users
1. Unzip this file
2. Double-click `install-windows.bat`
3. Follow the on-screen instructions

---

## Supported Games

- 🟩 **Wordle** - NYT word puzzle
- 🔗 **Connections** - NYT category puzzle
- 🧵 **Strands** - NYT word find
- 🐝 **Spelling Bee** - NYT spelling game
- 📝 **Mini Crossword** - NYT mini
- 📦 **Letter Boxed** - NYT word puzzle
- 🌍 **Worldle** - Country guessing
- 4️⃣ **Quordle** - 4x Wordle
- 8️⃣ **Octordle** - 8x Wordle

## Installation

### From Source (Developer Mode)

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the `gameshelf-extension` folder
5. The extension icon should appear in your toolbar

### Pinning the Extension

1. Click the puzzle piece icon in Chrome toolbar
2. Find "Game Shelf - Auto Logger"
3. Click the pin icon to keep it visible

## How It Works

1. **Auto-Detection**: When you complete a supported game, the extension detects it
2. **Notification**: You'll see a small toast notification confirming the log
3. **Pending Sync**: Games are stored locally until you sync
4. **Sync to Game Shelf**: Click the extension icon and "Sync to Game Shelf"

## Features

### Auto-Capture
- Detects game completion automatically
- Captures score/results when available
- Shows in-page notification

### Popup Dashboard
- See today's games at a glance
- View pending games awaiting sync
- One-click sync to Game Shelf

### Smart Logging
- Prevents duplicate logs for same day
- Tracks streak continuation
- Preserves historical data

## Permissions

- **storage**: Save pending games locally
- **activeTab**: Read game results from current tab
- **host_permissions**: Access supported game sites

## Privacy

- All data stored locally in browser
- Only syncs when you click "Sync"
- No data sent to third parties
- Your gaming stats stay private

## Troubleshooting

### Extension not detecting games?
- Make sure you're on a supported game site
- Complete the game (detection happens after finishing)
- Refresh the page and try again

### Sync not working?
- Check your internet connection
- Make sure Game Shelf website is accessible
- Try manual paste if auto-sync fails

## File Structure

```
gameshelf-extension/
├── manifest.json       # Extension configuration
├── background.js       # Service worker
├── popup.html         # Extension popup UI
├── popup.js           # Popup logic
├── content-nyt.js     # NYT Games detector
├── content-worldle.js # Worldle detector  
├── content-quordle.js # Quordle/Octordle detector
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

## Version History

### 1.0.0
- Initial release
- Support for 9 games
- Auto-detection and sync

---

Made with ❤️ for Game Shelf
