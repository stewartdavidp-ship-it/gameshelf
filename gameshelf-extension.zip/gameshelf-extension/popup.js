// Game Shelf Extension - Popup Script

const GAME_SHELF_URL = 'https://stewartdavidp-ship-it.github.io/GameShelf/gameshelf.html';

document.addEventListener('DOMContentLoaded', function() {
    loadData();
    
    document.getElementById('sync-btn').addEventListener('click', syncToGameShelf);
    document.getElementById('open-btn').addEventListener('click', openGameShelf);
});

function loadData() {
    chrome.storage.local.get(['pendingGames', 'loggedGames'], function(result) {
        const pendingGames = result.pendingGames || [];
        const loggedGames = result.loggedGames || {};
        
        // Count today's games
        const today = new Date().toISOString().split('T')[0];
        let todayCount = 0;
        
        Object.keys(loggedGames).forEach(key => {
            if (key.endsWith(today)) {
                todayCount++;
            }
        });
        
        // Update stats
        document.getElementById('today-count').textContent = todayCount;
        document.getElementById('pending-count').textContent = pendingGames.length;
        
        // Render games list
        renderGamesList(pendingGames, loggedGames, today);
    });
}

function renderGamesList(pendingGames, loggedGames, today) {
    const listEl = document.getElementById('games-list');
    
    // Build today's games from both pending and logged
    const todayGames = [];
    
    // Add pending games
    pendingGames.forEach(game => {
        if (game.date === today) {
            todayGames.push({
                ...game,
                status: 'pending'
            });
        }
    });
    
    // Add logged games (not in pending) 
    const gameIcons = {
        'wordle': '🟩',
        'connections': '🔗',
        'strands': '🧵',
        'spelling-bee': '🐝',
        'mini': '📝',
        'letterboxed': '📦',
        'worldle': '🌍',
        'quordle': '4️⃣',
        'octordle': '8️⃣'
    };
    
    const gameNames = {
        'wordle': 'Wordle',
        'connections': 'Connections',
        'strands': 'Strands',
        'spelling-bee': 'Spelling Bee',
        'mini': 'Mini Crossword',
        'letterboxed': 'Letter Boxed',
        'worldle': 'Worldle',
        'quordle': 'Quordle',
        'octordle': 'Octordle'
    };
    
    // Check logged games for today that aren't pending
    Object.keys(loggedGames).forEach(key => {
        if (key.endsWith(today)) {
            const gameId = key.replace(`-${today}`, '');
            const isPending = todayGames.some(g => g.id === gameId);
            
            if (!isPending) {
                todayGames.push({
                    id: gameId,
                    name: gameNames[gameId] || gameId,
                    icon: gameIcons[gameId] || '🎮',
                    score: 'Synced',
                    status: 'done'
                });
            }
        }
    });
    
    if (todayGames.length === 0) {
        listEl.innerHTML = `
            <div class="empty-state">
                <p>No games logged yet today</p>
                <p style="font-size: 0.75rem; margin-top: 5px;">Play a game and we'll detect it!</p>
            </div>
        `;
        return;
    }
    
    listEl.innerHTML = todayGames.map(game => `
        <div class="game-item">
            <div class="game-icon">${game.icon}</div>
            <div class="game-info">
                <div class="game-name">${game.name}</div>
                <div class="game-score">${game.score}</div>
            </div>
            <span class="game-status ${game.status}">${game.status === 'done' ? '✓ Synced' : '⏳ Pending'}</span>
        </div>
    `).join('');
}

function syncToGameShelf() {
    chrome.storage.local.get(['pendingGames'], function(result) {
        const pendingGames = result.pendingGames || [];
        
        if (pendingGames.length === 0) {
            alert('No pending games to sync!');
            return;
        }
        
        // Build URL with game data
        const syncData = encodeURIComponent(JSON.stringify(pendingGames));
        const syncUrl = `${GAME_SHELF_URL}?sync=${syncData}`;
        
        // Open Game Shelf with sync data
        chrome.tabs.create({ url: syncUrl }, function() {
            // Clear pending after opening
            chrome.storage.local.set({ pendingGames: [] }, function() {
                loadData();
            });
        });
    });
}

function openGameShelf() {
    chrome.tabs.create({ url: GAME_SHELF_URL });
}
