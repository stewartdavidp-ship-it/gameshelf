// Game Shelf Extension - Worldle Content Script

(function() {
    'use strict';
    
    const currentGame = { id: 'worldle', name: 'Worldle', icon: '🌍' };
    let hasLogged = false;
    
    console.log('[Game Shelf] Monitoring Worldle...');
    
    function detectCompletion() {
        // Look for share button or success message
        const shareButton = document.querySelector('[class*="share"], button[aria-label*="Share"]');
        const successEl = document.querySelector('[class*="success"], [class*="win"]');
        const guessRows = document.querySelectorAll('[class*="guess-row"], .guess');
        
        if ((shareButton || successEl) && guessRows.length > 0 && !hasLogged) {
            captureAndLog(guessRows.length);
        }
    }
    
    function captureAndLog(guesses) {
        hasLogged = true;
        
        const today = new Date().toISOString().split('T')[0];
        const gameData = {
            id: currentGame.id,
            name: currentGame.name,
            icon: currentGame.icon,
            score: `${guesses}/6`,
            date: today,
            timestamp: Date.now(),
            url: window.location.href
        };
        
        chrome.storage.local.get(['pendingGames', 'loggedGames'], function(result) {
            const pendingGames = result.pendingGames || [];
            const loggedGames = result.loggedGames || {};
            const todayKey = `${currentGame.id}-${today}`;
            
            if (loggedGames[todayKey]) return;
            
            pendingGames.push(gameData);
            loggedGames[todayKey] = true;
            
            chrome.storage.local.set({ pendingGames, loggedGames }, function() {
                showNotification(gameData);
            });
        });
        
        chrome.runtime.sendMessage({ type: 'GAME_COMPLETED', data: gameData });
    }
    
    function showNotification(gameData) {
        const notification = document.createElement('div');
        notification.id = 'gameshelf-notification';
        notification.innerHTML = `
            <style>
                #gameshelf-notification {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: white;
                    padding: 15px 20px;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                    z-index: 999999;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    animation: slideIn 0.3s ease;
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            </style>
            <div style="font-size: 2rem;">${gameData.icon}</div>
            <div>
                <div style="color: #ffd700; font-weight: 600;">✓ Logged to Game Shelf!</div>
                <div style="font-size: 0.8rem; opacity: 0.8;">${gameData.name} • ${gameData.score}</div>
            </div>
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 5000);
    }
    
    // Observer and interval
    const observer = new MutationObserver(detectCompletion);
    setTimeout(() => {
        observer.observe(document.body, { childList: true, subtree: true });
        detectCompletion();
    }, 2000);
    
    setInterval(detectCompletion, 5000);
})();
