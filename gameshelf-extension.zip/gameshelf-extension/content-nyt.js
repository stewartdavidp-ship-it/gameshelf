// Game Shelf Extension - NYT Games Content Script
// Detects game completions and captures results

(function() {
    'use strict';
    
    const GAME_SHELF_URL = 'https://stewartdavidp-ship-it.github.io/GameShelf/gameshelf.html';
    
    // Detect which NYT game we're on
    const url = window.location.href;
    let currentGame = null;
    
    if (url.includes('/games/wordle')) {
        currentGame = { id: 'wordle', name: 'Wordle', icon: '🟩' };
    } else if (url.includes('/games/connections')) {
        currentGame = { id: 'connections', name: 'Connections', icon: '🔗' };
    } else if (url.includes('/games/strands')) {
        currentGame = { id: 'strands', name: 'Strands', icon: '🧵' };
    } else if (url.includes('/games/spelling-bee')) {
        currentGame = { id: 'spelling-bee', name: 'Spelling Bee', icon: '🐝' };
    } else if (url.includes('/crosswords/game/mini')) {
        currentGame = { id: 'mini', name: 'Mini Crossword', icon: '📝' };
    } else if (url.includes('/games/letter-boxed')) {
        currentGame = { id: 'letterboxed', name: 'Letter Boxed', icon: '📦' };
    }
    
    if (!currentGame) return;
    
    console.log(`[Game Shelf] Monitoring ${currentGame.name}...`);
    
    // Track if we've already logged this session
    let hasLogged = false;
    
    // Look for share button clicks - most NYT games show share after completion
    function detectCompletion() {
        // Method 1: Look for share dialog/button
        const shareButton = document.querySelector('[data-testid="share-button"], .share-button, [aria-label*="Share"]');
        const statsModal = document.querySelector('.stats-modal, .game-stats, [class*="Stats"]');
        const winMessage = document.querySelector('[class*="win"], [class*="Win"], [class*="congratulation"]');
        
        // Method 2: Check for game completion indicators
        const isComplete = shareButton || statsModal || winMessage;
        
        if (isComplete && !hasLogged) {
            console.log(`[Game Shelf] ${currentGame.name} completion detected!`);
            captureAndLog();
        }
    }
    
    // Capture share text if available
    function getShareText() {
        // Try to find the share text element
        const shareTextEl = document.querySelector('[class*="share-text"], .share-content, [data-testid="share-text"]');
        if (shareTextEl) {
            return shareTextEl.textContent || shareTextEl.innerText;
        }
        
        // Try clipboard if available (from previous share)
        return null;
    }
    
    // Extract score based on game type
    function extractScore() {
        let score = 'Completed';
        
        switch(currentGame.id) {
            case 'wordle':
                // Look for guess count (1/6 - 6/6 or X/6)
                const wordleGuesses = document.querySelectorAll('[class*="Row-module_row"]').length;
                const wordleFailed = document.querySelector('[class*="lose"], .game-over');
                if (wordleFailed) {
                    score = 'X/6';
                } else if (wordleGuesses > 0) {
                    score = `${wordleGuesses}/6`;
                }
                break;
                
            case 'connections':
                // Count mistakes (wrong guesses shown as different colors)
                const connectionRows = document.querySelectorAll('[class*="Row"], .connection-group');
                const mistakes = Math.max(0, connectionRows.length - 4);
                score = `${mistakes} mistakes`;
                break;
                
            case 'strands':
                // Count hints used
                const hints = document.querySelectorAll('[class*="hint-used"], .hint').length;
                score = hints > 0 ? `${hints} hints` : 'No hints!';
                break;
                
            case 'spelling-bee':
                // Look for rank
                const rankEl = document.querySelector('[class*="rank"], .sb-progress-rank');
                if (rankEl) {
                    score = rankEl.textContent || 'Completed';
                }
                break;
                
            case 'mini':
                // Look for time
                const timeEl = document.querySelector('[class*="time"], .timer, [class*="Timer"]');
                if (timeEl) {
                    score = timeEl.textContent || 'Completed';
                }
                break;
                
            case 'letterboxed':
                // Count words used
                const wordsUsed = document.querySelectorAll('[class*="word"], .lb-word').length;
                if (wordsUsed > 0) {
                    score = `${wordsUsed} words`;
                }
                break;
        }
        
        return score;
    }
    
    // Log the game to Game Shelf
    function captureAndLog() {
        hasLogged = true;
        
        const shareText = getShareText();
        const score = extractScore();
        const today = new Date().toISOString().split('T')[0];
        
        const gameData = {
            id: currentGame.id,
            name: currentGame.name,
            icon: currentGame.icon,
            score: score,
            shareText: shareText,
            date: today,
            timestamp: Date.now(),
            url: window.location.href
        };
        
        console.log('[Game Shelf] Captured:', gameData);
        
        // Save to extension storage
        chrome.storage.local.get(['pendingGames', 'loggedGames'], function(result) {
            const pendingGames = result.pendingGames || [];
            const loggedGames = result.loggedGames || {};
            
            // Check if already logged today
            const todayKey = `${currentGame.id}-${today}`;
            if (loggedGames[todayKey]) {
                console.log('[Game Shelf] Already logged today');
                return;
            }
            
            // Add to pending
            pendingGames.push(gameData);
            loggedGames[todayKey] = true;
            
            chrome.storage.local.set({ 
                pendingGames: pendingGames,
                loggedGames: loggedGames 
            }, function() {
                console.log('[Game Shelf] Saved to pending');
                showNotification(gameData);
            });
        });
        
        // Also send message to background script
        chrome.runtime.sendMessage({
            type: 'GAME_COMPLETED',
            data: gameData
        });
    }
    
    // Show in-page notification
    function showNotification(gameData) {
        const notification = document.createElement('div');
        notification.id = 'gameshelf-notification';
        notification.innerHTML = `
            <style>
                #gameshelf-notification {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: white;
                    padding: 15px 20px;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                    z-index: 999999;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    animation: slideIn 0.3s ease;
                    max-width: 300px;
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                #gameshelf-notification .gs-icon {
                    font-size: 2rem;
                }
                #gameshelf-notification .gs-content h4 {
                    margin: 0 0 4px 0;
                    font-size: 0.9rem;
                    color: #ffd700;
                }
                #gameshelf-notification .gs-content p {
                    margin: 0;
                    font-size: 0.8rem;
                    opacity: 0.8;
                }
                #gameshelf-notification .gs-close {
                    position: absolute;
                    top: 8px;
                    right: 10px;
                    background: none;
                    border: none;
                    color: white;
                    opacity: 0.5;
                    cursor: pointer;
                    font-size: 1rem;
                }
                #gameshelf-notification .gs-close:hover {
                    opacity: 1;
                }
            </style>
            <div class="gs-icon">${gameData.icon}</div>
            <div class="gs-content">
                <h4>✓ Logged to Game Shelf!</h4>
                <p>${gameData.name} • ${gameData.score}</p>
            </div>
            <button class="gs-close" onclick="this.parentElement.remove()">×</button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.style.animation = 'slideIn 0.3s ease reverse';
                setTimeout(() => notification.remove(), 300);
            }
        }, 5000);
    }
    
    // Observe DOM for completion indicators
    const observer = new MutationObserver(function(mutations) {
        detectCompletion();
    });
    
    // Start observing after a short delay (let page load)
    setTimeout(() => {
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'data-state']
        });
        
        // Also check immediately
        detectCompletion();
    }, 2000);
    
    // Listen for share button clicks
    document.addEventListener('click', function(e) {
        const target = e.target;
        if (target.closest('[data-testid="share-button"], .share-button, [aria-label*="Share"], [class*="share"]')) {
            setTimeout(detectCompletion, 500);
        }
    }, true);
    
    // Check periodically for games that complete without clear indicators
    setInterval(detectCompletion, 5000);
    
})();
