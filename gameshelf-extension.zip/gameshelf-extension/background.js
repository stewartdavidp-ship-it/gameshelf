// Game Shelf Extension - Background Service Worker

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.type === 'GAME_COMPLETED') {
        console.log('[Game Shelf] Game completed:', message.data);
        
        // Update badge
        updateBadge();
        
        // Show notification
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: '🎮 Game Shelf',
            message: `${message.data.name} logged! Score: ${message.data.score}`
        });
    }
    
    return true;
});

// Update badge with pending count
function updateBadge() {
    chrome.storage.local.get(['pendingGames'], function(result) {
        const count = (result.pendingGames || []).length;
        
        if (count > 0) {
            chrome.action.setBadgeText({ text: count.toString() });
            chrome.action.setBadgeBackgroundColor({ color: '#ffd700' });
        } else {
            chrome.action.setBadgeText({ text: '' });
        }
    });
}

// Initialize badge on install/startup
chrome.runtime.onInstalled.addListener(updateBadge);
chrome.runtime.onStartup.addListener(updateBadge);

// Clean up old logged games (keep only last 30 days)
chrome.alarms.create('cleanup', { periodInMinutes: 60 * 24 }); // Daily

chrome.alarms.onAlarm.addListener(function(alarm) {
    if (alarm.name === 'cleanup') {
        cleanupOldData();
    }
});

function cleanupOldData() {
    chrome.storage.local.get(['loggedGames'], function(result) {
        const loggedGames = result.loggedGames || {};
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - 30);
        const cutoffStr = cutoff.toISOString().split('T')[0];
        
        const cleaned = {};
        Object.keys(loggedGames).forEach(key => {
            const date = key.split('-').slice(-3).join('-');
            if (date >= cutoffStr) {
                cleaned[key] = loggedGames[key];
            }
        });
        
        chrome.storage.local.set({ loggedGames: cleaned });
    });
}
