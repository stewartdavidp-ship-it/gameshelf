# Development Guide

## Overview

Game Shelf is developed collaboratively with Claude (AI assistant). This document describes the development workflow, session management, and best practices.

---

## Session-Based Development with Claude

Since Claude's file system resets between sessions, we use a zip-based workflow to maintain continuity.

### Starting a New Session

1. **Upload the project zip**
   ```
   Upload: gameshelf-project.zip
   ```

2. **Claude will unzip and show status**
   ```bash
   unzip gameshelf-project.zip
   cd gameshelf-project
   git log --oneline -5  # Show recent commits
   git status            # Check for any uncommitted changes
   ```

3. **Describe what you need**
   - Bug fixes: "The merch modal isn't displaying correctly"
   - New features: "Add a calendar view for game completions"
   - Refactoring: "Split the CSS into a separate file"

### During Development

Claude will:
1. Create a feature branch for significant changes
2. Make incremental commits with descriptive messages
3. Update CHANGELOG.md under `[Unreleased]`
4. Test changes where possible

### Ending a Session

1. **Claude will finalize changes**
   ```bash
   git add -A
   git commit -m "type(scope): description"
   git checkout main
   git merge feature-branch  # If applicable
   ```

2. **Claude will update documentation**
   - CHANGELOG.md with new changes
   - Version bump if releasing

3. **Claude will provide updated zip**
   ```bash
   zip -r gameshelf-project.zip gameshelf-project
   ```

4. **Download the new zip** for next session

---

## Making Requests

### Bug Reports

Provide:
- **What's broken**: "Merch modal doesn't scroll"
- **Steps to reproduce**: "Open menu → Click Merch Store → Try to scroll"
- **Expected behavior**: "Should scroll to see all items"
- **Screenshots**: If possible, attach screenshots
- **Browser/device**: "Chrome on iPhone 14"

Example:
> "The merch store modal isn't coming up correctly in sandbox. When I click 'Merch Store' from the menu, the modal appears but the items aren't visible."

### Feature Requests

Provide:
- **What you want**: "Add ability to filter gifts by category"
- **Why it's useful**: "Users can find gifts faster"
- **Any design ideas**: "Tabs for Sweets, Coffee, Tech, etc."

Example:
> "Can we add a search/filter to the merch store? Users should be able to filter by category like 'Coffee' or 'Candles' to find gifts faster."

### Refactoring Requests

Provide:
- **What to change**: "Move CSS to separate file"
- **Reason**: "Easier to maintain, better caching"
- **Constraints**: "Keep it working as single-file option too"

---

## Git Workflow

### Branch Naming

```
feat/description    # New features
fix/description     # Bug fixes
docs/description    # Documentation
refactor/description # Code refactoring
```

Examples:
- `feat/calendar-view`
- `fix/merch-modal-scroll`
- `docs/api-examples`
- `refactor/split-css`

### Commit Messages

Format:
```
type(scope): short description

[optional body with more details]

[optional footer with breaking changes or issues]
```

Types:
| Type | Use For |
|------|---------|
| `feat` | New features |
| `fix` | Bug fixes |
| `docs` | Documentation changes |
| `style` | Formatting, no code change |
| `refactor` | Code restructuring |
| `perf` | Performance improvements |
| `test` | Adding tests |
| `chore` | Maintenance tasks |

Examples:
```bash
feat(merch): add category filtering to gift tiers
fix(battle): resolve score calculation for Wordle
docs: add API rate limiting notes
refactor(wallet): extract coin logic to separate functions
```

### Version Bumping

We use [Semantic Versioning](https://semver.org/):

- **MAJOR** (X.0.0): Breaking changes
- **MINOR** (0.X.0): New features, backward compatible
- **PATCH** (0.0.X): Bug fixes

To release a new version:
1. Update version in `gameshelf.html` (2 places)
2. Update version in `sw.js` cache name
3. Move `[Unreleased]` changes to new version in CHANGELOG.md
4. Commit: `chore: bump version to X.Y.Z`
5. Tag: `git tag vX.Y.Z`

---

## Testing

### Manual Testing Checklist

Before considering a feature complete:

- [ ] Works in Chrome (desktop)
- [ ] Works in Safari (desktop)
- [ ] Works in Chrome (mobile)
- [ ] Works in Safari (iOS)
- [ ] Works in dark mode
- [ ] Works in light mode
- [ ] Works offline (PWA)
- [ ] No console errors
- [ ] Responsive at 320px width
- [ ] Responsive at 1920px width

### Testing Specific Features

**Merch Store:**
- [ ] Modal opens correctly
- [ ] All tiers display with correct prices
- [ ] "Browse" opens tier details
- [ ] Redemption flow works
- [ ] Balance updates correctly

**Brain Battles:**
- [ ] Can create 1v1 challenge
- [ ] Can create group battle
- [ ] Scores calculate correctly
- [ ] Winner determined properly

**Wallet:**
- [ ] Balance displays in header
- [ ] Coins earned on game completion
- [ ] Transaction history accurate
- [ ] Streak bonuses awarded

### Sandbox Testing

The Claude.ai artifact sandbox has limitations:
- No localStorage persistence
- No Firebase connectivity
- Limited network access

For sandbox testing, the app should:
- Fall back gracefully when Firebase unavailable
- Use mock data where needed
- Not require sign-in for basic functionality

---

## Code Style

### JavaScript

- Use `const` by default, `let` when reassignment needed
- Use template literals for string interpolation
- Use async/await over .then() chains
- Add JSDoc comments for complex functions

```javascript
/**
 * Awards coins to user and logs transaction
 * @param {number} amount - Coins to award
 * @param {string} reason - Description for transaction log
 */
function earnCoins(amount, reason) {
    // ...
}
```

### CSS

- Use CSS custom properties (variables) for colors
- Mobile-first responsive design
- Use flexbox/grid over floats
- Group related styles with comments

```css
/* === Merch Store === */
.merch-modal { }
.merch-card { }
.merch-price { }
```

### HTML

- Use semantic elements where appropriate
- Include aria-labels for accessibility
- Keep inline styles minimal (use classes)

---

## File Organization

Current structure (single-file PWA):
```
gameshelf.html    # Everything in one file
├── <style>       # All CSS (~2000 lines)
├── <body>        # All HTML (~800 lines)  
└── <script>      # All JavaScript (~8000 lines)
```

Future consideration (if complexity warrants):
```
gameshelf/
├── index.html
├── css/
│   ├── main.css
│   ├── modals.css
│   └── themes.css
├── js/
│   ├── app.js
│   ├── firebase.js
│   ├── wallet.js
│   ├── battles.js
│   └── merch.js
└── assets/
    └── icons/
```

---

## Debugging Tips

### Common Issues

**Modal not displaying:**
```javascript
// Check if element exists
console.log(document.getElementById('modal-id'));
// Check if class is being added
modal.classList.add('active');
console.log(modal.classList.contains('active'));
```

**Data not persisting:**
```javascript
// Check localStorage
console.log(localStorage.getItem('gameShelfData'));
// Check userData object
console.log(JSON.stringify(userData, null, 2));
```

**Firebase not syncing:**
```javascript
// Check Firebase status
console.log('Firebase ready:', isFirebaseReady);
console.log('Current user:', currentUser);
```

### Browser DevTools

- **Elements tab**: Inspect modal visibility, CSS issues
- **Console tab**: JavaScript errors, log statements
- **Network tab**: Firebase/API calls
- **Application tab**: localStorage, service worker status

---

## Questions?

If you're unsure about something:
1. Ask Claude to explain the current implementation
2. Request a code walkthrough of specific functions
3. Ask for pros/cons of different approaches

Claude can provide context from the codebase and documentation to help make decisions.
