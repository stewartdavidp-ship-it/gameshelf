# 🎮 Game Shelf

**Your Daily Puzzle Hub** - Track daily puzzle games, build streaks, compete with friends, and earn rewards.

## Overview

Game Shelf is a Progressive Web App (PWA) that helps puzzle enthusiasts:
- Track completion of daily puzzle games (Wordle, Connections, Mini Crossword, etc.)
- Build and maintain streaks across multiple games
- Compete in Brain Battles™ with friends
- Earn Shelf Coins™ and redeem for real gifts via Goody

## Current Version

**v1.22.0** - See [CHANGELOG.md](./CHANGELOG.md) for full version history.

## Features

### 📊 Game Tracking
- Support for 10+ popular daily puzzle games
- Automatic streak tracking
- Manual result logging or Chrome extension auto-capture
- Daily/weekly/monthly statistics

### 🏆 Brain Battles™
- 1v1 friend challenges
- Group competitions (2-20 players)
- Public tournaments (Last Person Standing, High Score)
- Customizable stakes and durations

### 🪙 Shelf Coins™ Economy
- Earn coins through gameplay, streaks, and achievements
- Spend on Brain Battle entry fees
- Redeem for real gifts via Goody integration

### 🎁 Merch Store
- **Virtual Rewards**: Profile frames, badges, titles (earned through competition)
- **Physical Gifts**: Goody Gift of Choice tiers ($15-$100+)
  - Curated preview of available items
  - Full catalog access via Goody email link
  - Free shipping included

### 👥 Social Features
- Friends system with activity feeds
- Leaderboards
- Share results and achievements

## Tech Stack

- **Frontend**: Vanilla HTML/CSS/JavaScript (single-file PWA)
- **Backend**: Firebase (Authentication, Realtime Database)
- **Integrations**: 
  - Goody Commerce API (gift fulfillment)
  - Chrome Extension (auto-logging)

## Project Structure

```
gameshelf-project/
├── gameshelf.html      # Main application (single-file PWA)
├── manifest.json       # PWA manifest
├── sw.js              # Service worker for offline support
├── README.md          # This file
├── CHANGELOG.md       # Version history
├── CONTRIBUTING.md    # Contribution guidelines
├── DEVELOPMENT.md     # Development workflow with Claude
└── docs/
    ├── ARCHITECTURE.md    # Technical architecture
    ├── FEATURES.md        # Feature specifications
    └── API-INTEGRATION.md # Third-party API docs
```

## Quick Links

| Document | Description |
|----------|-------------|
| [CHANGELOG.md](./CHANGELOG.md) | Version history and release notes |
| [CONTRIBUTING.md](./CONTRIBUTING.md) | How to contribute, code standards |
| [DEVELOPMENT.md](./DEVELOPMENT.md) | Development workflow with Claude |
| [ARCHITECTURE.md](./docs/ARCHITECTURE.md) | Technical design and data flow |
| [FEATURES.md](./docs/FEATURES.md) | Feature status and roadmap |
| [API-INTEGRATION.md](./docs/API-INTEGRATION.md) | Goody API and Firebase setup |

## Development

### Local Development
Simply open `gameshelf.html` in a browser. No build step required.

### Firebase Setup
The app uses a shared Firebase project (`word-boxing`). To use your own:
1. Create a Firebase project
2. Enable Authentication (Google provider)
3. Enable Realtime Database
4. Update `firebaseConfig` in gameshelf.html

### Goody Integration
Physical gift fulfillment requires Goody API credentials:
1. Sign up at https://business.ongoody.com
2. Obtain API key
3. Configure endpoints in the merch store functions

## Deployment

The app can be deployed to any static hosting:
- GitHub Pages
- Netlify
- Vercel
- Firebase Hosting

## Contributing

1. Create a feature branch from `main`
2. Follow the commit message convention (see below)
3. Update CHANGELOG.md with your changes
4. Submit a pull request

### Commit Message Convention

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding/updating tests
- `chore`: Maintenance tasks

Examples:
```
feat(merch): add Goody Gift Tier browsing modal
fix(battle): resolve score sync issue in group competitions
docs: update README with deployment instructions
```

## License

Proprietary - © 2025-2026 RB Games

## Contact

For questions or support, reach out through the app's feedback system.
