/**
 * GAME SHELF - Share Text Parser Module
 * Version: 1.0.0
 * 
 * Universal parser for game share texts with normalized scoring for contests.
 * Designed to extract maximum data for analytics and head-to-head competitions.
 * 
 * ARCHITECTURE:
 * - GameParser: Individual game parsing with regex + extraction
 * - NormalizedResult: Standard format for all games
 * - ContestScoring: Point-based system for fair comparisons
 * - GameSignature: Auto-detect which game from share text
 */

// ============================================================================
// NORMALIZED RESULT SCHEMA
// ============================================================================

/**
 * Standard result format returned by all parsers
 * @typedef {Object} NormalizedResult
 * @property {string} gameId - Unique identifier (e.g., 'wordle', 'connections')
 * @property {string} gameName - Display name (e.g., 'Wordle', 'Connections')
 * @property {string} icon - Emoji icon for the game
 * @property {string} puzzleNumber - The puzzle/day number (e.g., '1234')
 * @property {string} displayScore - Human-readable score (e.g., '4/6', '2:15')
 * @property {boolean} success - Whether the puzzle was solved
 * @property {boolean} perfect - Whether it was a perfect solve
 * @property {Object} raw - Raw extracted values for analytics
 * @property {number} contestPoints - Normalized 0-100 points for contests
 * @property {string} source - Where the game is from (e.g., 'nyt', 'indie')
 * @property {Date} parsedAt - Timestamp of parsing
 */

// ============================================================================
// CONTEST SCORING SYSTEM
// ============================================================================

/**
 * Normalized scoring (0-100 scale) for fair contest comparisons
 * Higher is always better. This allows different game types to compete.
 */
const ContestScoring = {
    // Wordle-style (guess games): fewer guesses = higher score
    guessGame: (guesses, maxGuesses, failed = false) => {
        if (failed) return 0;
        // Perfect (1 guess) = 100, worst possible = ~17
        return Math.round((1 - ((guesses - 1) / maxGuesses)) * 100);
    },
    
    // Time-based games: faster = higher score
    timeGame: (seconds, parTime = 120, maxTime = 600) => {
        if (seconds <= parTime / 2) return 100; // Under half par = perfect
        if (seconds >= maxTime) return 10; // Over max = minimum
        // Linear scale between
        return Math.round(100 - ((seconds - parTime / 2) / (maxTime - parTime / 2)) * 90);
    },
    
    // Mistake/hint games: fewer = higher score
    mistakeGame: (mistakes, maxMistakes) => {
        return Math.round((1 - (mistakes / maxMistakes)) * 100);
    },
    
    // Completion games: binary success/fail with optional bonus
    completionGame: (success, bonus = 0) => {
        return success ? Math.min(100, 70 + bonus) : 0;
    },
    
    // Grid games (like Connections): based on category completion
    gridGame: (correct, total, mistakes = 0) => {
        const baseScore = (correct / total) * 80;
        const mistakePenalty = mistakes * 5;
        return Math.max(0, Math.round(baseScore + 20 - mistakePenalty));
    }
};

// ============================================================================
// GAME PARSERS
// ============================================================================

const GameParsers = {
    // -------------------------------------------------------------------------
    // NEW YORK TIMES GAMES
    // -------------------------------------------------------------------------
    
    wordle: {
        id: 'wordle',
        name: 'Wordle',
        icon: '🟩',
        source: 'nyt',
        patterns: [
            /Wordle\s+([\d,]+)\s+([1-6X])\/6/i,
            /Wordle\s+([\d,]+)\s+🎉\s*([1-6])\/6/i // With celebration emoji
        ],
        extract: (match, text) => {
            const puzzleNum = match[1].replace(',', '');
            const guesses = match[2];
            const failed = guesses === 'X';
            const numGuesses = failed ? 7 : parseInt(guesses);
            
            // Count row colors for analytics
            const rows = text.split('\n').filter(l => /^[⬛⬜🟨🟩]+$/.test(l.trim()));
            const greenCount = (text.match(/🟩/g) || []).length;
            const yellowCount = (text.match(/🟨/g) || []).length;
            
            return {
                gameId: 'wordle',
                gameName: 'Wordle',
                icon: '🟩',
                puzzleNumber: puzzleNum,
                displayScore: `${guesses}/6`,
                success: !failed,
                perfect: numGuesses === 1,
                raw: {
                    guesses: numGuesses,
                    maxGuesses: 6,
                    failed,
                    greenCount,
                    yellowCount,
                    rows: rows.length
                },
                contestPoints: ContestScoring.guessGame(numGuesses, 6, failed),
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    connections: {
        id: 'connections',
        name: 'Connections',
        icon: '🔗',
        source: 'nyt',
        patterns: [
            /Connections\s*\n?Puzzle\s*#?(\d+)/i,
            /Connections\s*(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse the grid - each row is a guess
            const colorRows = text.split('\n').filter(l => 
                /^[🟨🟩🟦🟪]{4,}$/.test(l.trim().replace(/\s/g, ''))
            );
            
            // Count successful categories (rows of same color)
            let successfulCategories = 0;
            let mistakes = 0;
            
            colorRows.forEach(row => {
                const colors = row.trim().replace(/\s/g, '');
                if (colors.length === 4 && new Set([...colors]).size === 1) {
                    successfulCategories++;
                } else {
                    mistakes++;
                }
            });
            
            // Also detect order (which colors were solved first)
            const colorOrder = colorRows
                .filter(row => {
                    const colors = row.trim().replace(/\s/g, '');
                    return colors.length === 4 && new Set([...colors]).size === 1;
                })
                .map(row => row.trim()[0]);
            
            const solved = successfulCategories === 4;
            const perfect = solved && mistakes === 0;
            
            return {
                gameId: 'connections',
                gameName: 'Connections',
                icon: '🔗',
                puzzleNumber: puzzleNum,
                displayScore: perfect ? 'Perfect!' : `${mistakes} mistake${mistakes !== 1 ? 's' : ''}`,
                success: solved,
                perfect,
                raw: {
                    categoriesSolved: successfulCategories,
                    mistakes,
                    totalGuesses: colorRows.length,
                    colorOrder,
                    solvedYellow: colorOrder.includes('🟨'),
                    solvedGreen: colorOrder.includes('🟩'),
                    solvedBlue: colorOrder.includes('🟦'),
                    solvedPurple: colorOrder.includes('🟪')
                },
                contestPoints: solved 
                    ? ContestScoring.gridGame(4, 4, mistakes)
                    : ContestScoring.gridGame(successfulCategories, 4, mistakes),
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    strands: {
        id: 'strands',
        name: 'Strands',
        icon: '🧵',
        source: 'nyt',
        patterns: [
            /Strands\s*#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Count hints used (💡) and theme words found (🔵) and spangram (🟡)
            const hints = (text.match(/💡/g) || []).length;
            const themeWords = (text.match(/🔵/g) || []).length;
            const spangram = (text.match(/🟡/g) || []).length;
            
            const perfect = hints === 0;
            
            return {
                gameId: 'strands',
                gameName: 'Strands',
                icon: '🧵',
                puzzleNumber: puzzleNum,
                displayScore: hints === 0 ? 'No hints! ⭐' : `${hints} hint${hints !== 1 ? 's' : ''}`,
                success: true, // Strands doesn't have fail state in share
                perfect,
                raw: {
                    hints,
                    themeWords,
                    spangram,
                    totalWords: themeWords + spangram
                },
                contestPoints: ContestScoring.mistakeGame(hints, 5),
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    spellingBee: {
        id: 'spelling-bee',
        name: 'Spelling Bee',
        icon: '🐝',
        source: 'nyt',
        patterns: [
            /Spelling\s*Bee/i,
            /🐝.*?(Genius|Queen\s*Bee|Amazing|Great|Nice|Solid|Good|Moving Up|Good Start|Beginner)/i
        ],
        extract: (match, text) => {
            // Detect rank from share text
            const ranks = ['Beginner', 'Good Start', 'Moving Up', 'Good', 'Solid', 'Nice', 'Great', 'Amazing', 'Genius', 'Queen Bee'];
            let detectedRank = 'Completed';
            let rankIndex = 0;
            
            for (let i = ranks.length - 1; i >= 0; i--) {
                if (text.toLowerCase().includes(ranks[i].toLowerCase())) {
                    detectedRank = ranks[i];
                    rankIndex = i;
                    break;
                }
            }
            
            const isQueenBee = detectedRank === 'Queen Bee';
            const isGenius = detectedRank === 'Genius' || isQueenBee;
            
            // Try to extract points if present
            const pointsMatch = text.match(/(\d+)\s*points?/i);
            const points = pointsMatch ? parseInt(pointsMatch[1]) : null;
            
            // Try to extract word count
            const wordsMatch = text.match(/(\d+)\s*words?/i);
            const words = wordsMatch ? parseInt(wordsMatch[1]) : null;
            
            return {
                gameId: 'spelling-bee',
                gameName: 'Spelling Bee',
                icon: '🐝',
                puzzleNumber: null, // Spelling Bee doesn't have puzzle numbers
                displayScore: isQueenBee ? 'Queen Bee! 👑' : detectedRank,
                success: isGenius,
                perfect: isQueenBee,
                raw: {
                    rank: detectedRank,
                    rankIndex,
                    points,
                    words,
                    isGenius,
                    isQueenBee
                },
                contestPoints: Math.round((rankIndex / (ranks.length - 1)) * 100),
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    mini: {
        id: 'mini',
        name: 'Mini Crossword',
        icon: '📝',
        source: 'nyt',
        patterns: [
            /(?:I\s+solved\s+)?(?:the\s+)?(\d+\/\d+)?\s*(?:New\s+York\s+Times\s+)?Mini\s*(?:Crossword)?\s*(?:in\s+)?(\d+):(\d+)/i,
            /Mini\s*(?:Crossword)?\s*(\d+):(\d+)/i
        ],
        extract: (match, text) => {
            // Handle different match groups
            let minutes, seconds;
            if (match[3]) {
                minutes = parseInt(match[2]);
                seconds = parseInt(match[3]);
            } else {
                minutes = parseInt(match[1]);
                seconds = parseInt(match[2]);
            }
            
            const totalSeconds = minutes * 60 + seconds;
            const timeStr = `${minutes}:${String(seconds).padStart(2, '0')}`;
            
            // Extract date if present
            const dateMatch = text.match(/(\d+)\/(\d+)/);
            const puzzleDate = dateMatch ? `${dateMatch[1]}/${dateMatch[2]}` : null;
            
            // Determine quality tier
            let tier;
            if (totalSeconds < 30) tier = 'lightning';
            else if (totalSeconds < 60) tier = 'fast';
            else if (totalSeconds < 120) tier = 'good';
            else if (totalSeconds < 180) tier = 'average';
            else tier = 'slow';
            
            return {
                gameId: 'mini',
                gameName: 'Mini Crossword',
                icon: '📝',
                puzzleNumber: puzzleDate,
                displayScore: timeStr,
                success: true,
                perfect: totalSeconds < 30,
                raw: {
                    minutes,
                    seconds,
                    totalSeconds,
                    tier,
                    puzzleDate
                },
                contestPoints: ContestScoring.timeGame(totalSeconds, 60, 300),
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    letterBoxed: {
        id: 'letterboxed',
        name: 'Letter Boxed',
        icon: '📦',
        source: 'nyt',
        patterns: [
            /Letter\s*Boxed/i,
            /I\s+solved.*Letter.*in\s+(\d+)\s+word/i
        ],
        extract: (match, text) => {
            const wordMatch = text.match(/in\s+(\d+)\s+word/i);
            const words = wordMatch ? parseInt(wordMatch[1]) : null;
            
            // 2 words is the goal, anything more is still success
            const perfect = words === 2;
            
            return {
                gameId: 'letterboxed',
                gameName: 'Letter Boxed',
                icon: '📦',
                puzzleNumber: null,
                displayScore: words ? `${words} word${words !== 1 ? 's' : ''}` : 'Completed',
                success: true,
                perfect,
                raw: {
                    words,
                    isOptimal: words === 2,
                    isThreeWord: words === 3
                },
                contestPoints: words 
                    ? Math.max(10, 100 - ((words - 2) * 20))
                    : 50,
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    tiles: {
        id: 'tiles',
        name: 'Tiles',
        icon: '🀄',
        source: 'nyt',
        patterns: [
            /Tiles\s*#?(\d+)/i,
            /I\s+matched.*Tiles.*in\s+(\d+):(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Try to extract time
            const timeMatch = text.match(/(\d+):(\d+)/);
            let minutes = 0, seconds = 0, totalSeconds = null;
            
            if (timeMatch) {
                minutes = parseInt(timeMatch[1]);
                seconds = parseInt(timeMatch[2]);
                totalSeconds = minutes * 60 + seconds;
            }
            
            return {
                gameId: 'tiles',
                gameName: 'Tiles',
                icon: '🀄',
                puzzleNumber: puzzleNum || null,
                displayScore: totalSeconds 
                    ? `${minutes}:${String(seconds).padStart(2, '0')}`
                    : 'Completed',
                success: true,
                perfect: totalSeconds && totalSeconds < 60,
                raw: {
                    minutes,
                    seconds,
                    totalSeconds
                },
                contestPoints: totalSeconds 
                    ? ContestScoring.timeGame(totalSeconds, 90, 300)
                    : 50,
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },
    
    vertex: {
        id: 'vertex',
        name: 'Vertex',
        icon: '📐',
        source: 'nyt',
        patterns: [
            /Vertex\s*#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            return {
                gameId: 'vertex',
                gameName: 'Vertex',
                icon: '📐',
                puzzleNumber: puzzleNum || null,
                displayScore: 'Completed',
                success: true,
                perfect: false,
                raw: {},
                contestPoints: 70,
                source: 'nyt',
                parsedAt: new Date()
            };
        }
    },

    // -------------------------------------------------------------------------
    // WORDLE VARIANTS
    // -------------------------------------------------------------------------
    
    quordle: {
        id: 'quordle',
        name: 'Quordle',
        icon: '4️⃣',
        source: 'merriam-webster',
        patterns: [
            /Daily\s+Quordle\s+(\d+)/i,
            /Quordle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse the 2x2 grid of scores
            const scoreMatch = text.match(/([1-9🟥])[\s\n]*([1-9🟥])[\s\n]*([1-9🟥])[\s\n]*([1-9🟥])/);
            let scores = [9, 9, 9, 9];
            let failed = 0;
            
            if (scoreMatch) {
                scores = [1, 2, 3, 4].map(i => {
                    const val = scoreMatch[i];
                    if (val === '🟥' || val === 'X') {
                        failed++;
                        return 10;
                    }
                    return parseInt(val) || 9;
                });
            }
            
            const avgScore = scores.reduce((a, b) => a + b, 0) / 4;
            const solved = failed === 0;
            
            return {
                gameId: 'quordle',
                gameName: 'Quordle',
                icon: '4️⃣',
                puzzleNumber: puzzleNum,
                displayScore: solved ? `Avg: ${avgScore.toFixed(1)}` : `${4 - failed}/4 solved`,
                success: solved,
                perfect: solved && avgScore <= 5,
                raw: {
                    scores,
                    avgScore,
                    failed,
                    totalGuesses: scores.reduce((a, b) => a + b, 0)
                },
                contestPoints: solved 
                    ? Math.round(100 - (avgScore - 3) * 10)
                    : Math.round(((4 - failed) / 4) * 50),
                source: 'merriam-webster',
                parsedAt: new Date()
            };
        }
    },
    
    octordle: {
        id: 'octordle',
        name: 'Octordle',
        icon: '8️⃣',
        source: 'octordle',
        patterns: [
            /Daily\s+Octordle\s+#?(\d+)/i,
            /Octordle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse score grid (typically shows 🔟 for 10+)
            const scores = [];
            const scoreLines = text.split('\n').filter(l => /[1-9🔟🟥]/.test(l));
            
            scoreLines.forEach(line => {
                const matches = line.match(/[1-9]|🔟|🟥/g) || [];
                matches.forEach(m => {
                    if (m === '🟥') scores.push(14);
                    else if (m === '🔟') scores.push(10);
                    else scores.push(parseInt(m));
                });
            });
            
            const solved = scores.filter(s => s < 14).length;
            const avgScore = scores.length > 0 
                ? scores.reduce((a, b) => a + b, 0) / scores.length 
                : 0;
            
            return {
                gameId: 'octordle',
                gameName: 'Octordle',
                icon: '8️⃣',
                puzzleNumber: puzzleNum,
                displayScore: `${solved}/8 solved`,
                success: solved === 8,
                perfect: solved === 8 && avgScore <= 8,
                raw: {
                    scores,
                    solved,
                    avgScore
                },
                contestPoints: Math.round((solved / 8) * 100),
                source: 'octordle',
                parsedAt: new Date()
            };
        }
    },
    
    // -------------------------------------------------------------------------
    // GEOGRAPHY GAMES
    // -------------------------------------------------------------------------
    
    worldle: {
        id: 'worldle',
        name: 'Worldle',
        icon: '🌍',
        source: 'worldle',
        patterns: [
            /#Worldle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Count guess rows
            const rows = text.split('\n').filter(l => 
                /[🟩🟨⬛🟧⬜]/.test(l) && /[⬆⬇⬅➡↗↘↙↖]|🎉/.test(l)
            );
            
            const guesses = rows.length;
            const solved = text.includes('🎉') || text.includes('🟩');
            
            return {
                gameId: 'worldle',
                gameName: 'Worldle',
                icon: '🌍',
                puzzleNumber: puzzleNum,
                displayScore: solved ? `${guesses}/6` : 'X/6',
                success: solved,
                perfect: guesses === 1,
                raw: {
                    guesses,
                    maxGuesses: 6
                },
                contestPoints: solved 
                    ? ContestScoring.guessGame(guesses, 6, false)
                    : 0,
                source: 'worldle',
                parsedAt: new Date()
            };
        }
    },
    
    globle: {
        id: 'globle',
        name: 'Globle',
        icon: '🌎',
        source: 'globle',
        patterns: [
            /🌎\s*\w+\s+\d+,\s+\d+\s*🌍/i,
            /Globle/i
        ],
        extract: (match, text) => {
            // Try to extract guess count
            const guessMatch = text.match(/=\s*(\d+)/);
            const guesses = guessMatch ? parseInt(guessMatch[1]) : null;
            
            return {
                gameId: 'globle',
                gameName: 'Globle',
                icon: '🌎',
                puzzleNumber: null,
                displayScore: guesses ? `${guesses} guesses` : 'Completed',
                success: true,
                perfect: guesses && guesses <= 3,
                raw: {
                    guesses
                },
                contestPoints: guesses 
                    ? Math.max(10, 100 - (guesses * 5))
                    : 50,
                source: 'globle',
                parsedAt: new Date()
            };
        }
    },
    
    tradle: {
        id: 'tradle',
        name: 'Tradle',
        icon: '🚢',
        source: 'tradle',
        patterns: [
            /#Tradle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const guessMatch = text.match(/([1-6X])\/6/);
            const guesses = guessMatch ? guessMatch[1] : null;
            const failed = guesses === 'X';
            
            return {
                gameId: 'tradle',
                gameName: 'Tradle',
                icon: '🚢',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses}/6` : 'Completed',
                success: !failed,
                perfect: guesses === '1',
                raw: {
                    guesses: failed ? 7 : parseInt(guesses) || null,
                    failed
                },
                contestPoints: failed 
                    ? 0 
                    : guesses 
                        ? ContestScoring.guessGame(parseInt(guesses), 6, false)
                        : 50,
                source: 'tradle',
                parsedAt: new Date()
            };
        }
    },
    
    // -------------------------------------------------------------------------
    // TRIVIA / KNOWLEDGE GAMES
    // -------------------------------------------------------------------------
    
    framed: {
        id: 'framed',
        name: 'Framed',
        icon: '🎬',
        source: 'framed',
        patterns: [
            /Framed\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Count frames (🎥 = skip, 🟥 = wrong, 🟩 = correct)
            const frames = (text.match(/[🎥🟥🟩]/g) || []);
            const guessIndex = frames.findIndex(f => f === '🟩');
            const solved = guessIndex !== -1;
            const guesses = solved ? guessIndex + 1 : frames.length;
            
            return {
                gameId: 'framed',
                gameName: 'Framed',
                icon: '🎬',
                puzzleNumber: puzzleNum,
                displayScore: solved ? `${guesses}/6` : 'X/6',
                success: solved,
                perfect: guesses === 1,
                raw: {
                    guesses,
                    frames: frames.length,
                    skips: frames.filter(f => f === '🎥').length,
                    wrong: frames.filter(f => f === '🟥').length
                },
                contestPoints: solved 
                    ? ContestScoring.guessGame(guesses, 6, false)
                    : 0,
                source: 'framed',
                parsedAt: new Date()
            };
        }
    },
    
    nerdle: {
        id: 'nerdle',
        name: 'Nerdle',
        icon: '🧮',
        source: 'nerdle',
        patterns: [
            /nerdlegame\s+(\d+)/i,
            /Nerdle\s+(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const guessMatch = text.match(/([1-6X])\/6/);
            const guesses = guessMatch ? guessMatch[1] : null;
            const failed = guesses === 'X';
            
            return {
                gameId: 'nerdle',
                gameName: 'Nerdle',
                icon: '🧮',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses}/6` : 'Completed',
                success: !failed,
                perfect: guesses === '1',
                raw: {
                    guesses: failed ? 7 : parseInt(guesses) || null,
                    failed
                },
                contestPoints: failed 
                    ? 0 
                    : guesses 
                        ? ContestScoring.guessGame(parseInt(guesses), 6, false)
                        : 50,
                source: 'nerdle',
                parsedAt: new Date()
            };
        }
    },
    
    redactle: {
        id: 'redactle',
        name: 'Redactle',
        icon: '█',
        source: 'redactle',
        patterns: [
            /Redactle\s+#?(\d+)/i,
            /I\s+solved\s+Redactle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const guessMatch = text.match(/(\d+)\s+guesses?/i);
            const guesses = guessMatch ? parseInt(guessMatch[1]) : null;
            const accuracyMatch = text.match(/([\d.]+)%\s*accuracy/i);
            const accuracy = accuracyMatch ? parseFloat(accuracyMatch[1]) : null;
            
            return {
                gameId: 'redactle',
                gameName: 'Redactle',
                icon: '█',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses} guesses` : 'Completed',
                success: true,
                perfect: guesses && guesses <= 20,
                raw: {
                    guesses,
                    accuracy
                },
                contestPoints: guesses 
                    ? Math.max(10, 100 - Math.floor(guesses / 2))
                    : 50,
                source: 'redactle',
                parsedAt: new Date()
            };
        }
    },
    
    semantle: {
        id: 'semantle',
        name: 'Semantle',
        icon: '🧠',
        source: 'semantle',
        patterns: [
            /Semantle\s+#?(\d+)/i,
            /I\s+solved\s+Semantle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const guessMatch = text.match(/(\d+)\s+guesses?/i);
            const guesses = guessMatch ? parseInt(guessMatch[1]) : null;
            
            return {
                gameId: 'semantle',
                gameName: 'Semantle',
                icon: '🧠',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses} guesses` : 'Completed',
                success: true,
                perfect: guesses && guesses <= 30,
                raw: {
                    guesses
                },
                contestPoints: guesses 
                    ? Math.max(10, 100 - Math.floor(guesses / 3))
                    : 50,
                source: 'semantle',
                parsedAt: new Date()
            };
        }
    },
    
    // -------------------------------------------------------------------------
    // SPORTS GAMES
    // -------------------------------------------------------------------------
    
    immaculateGrid: {
        id: 'immaculate-grid',
        name: 'Immaculate Grid',
        icon: '⚾',
        source: 'immaculate-grid',
        patterns: [
            /Immaculate\s+Grid\s+#?(\d+)?/i,
            /⚾.*?(\d+)\/9/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const scoreMatch = text.match(/(\d+)\/9/);
            const correct = scoreMatch ? parseInt(scoreMatch[1]) : null;
            
            // Try to get rarity score
            const rarityMatch = text.match(/Rarity:\s*(\d+)/i);
            const rarity = rarityMatch ? parseInt(rarityMatch[1]) : null;
            
            return {
                gameId: 'immaculate-grid',
                gameName: 'Immaculate Grid',
                icon: '⚾',
                puzzleNumber: puzzleNum,
                displayScore: correct !== null ? `${correct}/9` : 'Completed',
                success: correct >= 5,
                perfect: correct === 9,
                raw: {
                    correct,
                    total: 9,
                    rarity
                },
                contestPoints: correct !== null 
                    ? Math.round((correct / 9) * 100)
                    : 50,
                source: 'immaculate-grid',
                parsedAt: new Date()
            };
        }
    },
    
    // -------------------------------------------------------------------------
    // FUN / MISC GAMES
    // -------------------------------------------------------------------------
    
    costcodle: {
        id: 'costcodle',
        name: 'Costcodle',
        icon: '🛒',
        source: 'costcodle',
        patterns: [
            /Costcodle\s+#?(\d+)/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            const guessMatch = text.match(/([1-6X])\/6/);
            const guesses = guessMatch ? guessMatch[1] : null;
            const failed = guesses === 'X';
            
            return {
                gameId: 'costcodle',
                gameName: 'Costcodle',
                icon: '🛒',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses}/6` : 'Completed',
                success: !failed,
                perfect: guesses === '1',
                raw: {
                    guesses: failed ? 7 : parseInt(guesses) || null,
                    failed
                },
                contestPoints: failed 
                    ? 0 
                    : guesses 
                        ? ContestScoring.guessGame(parseInt(guesses), 6, false)
                        : 50,
                source: 'costcodle',
                parsedAt: new Date()
            };
        }
    },
    
    foodguessr: {
        id: 'foodguessr',
        name: 'FoodGuessr',
        icon: '🍔',
        source: 'foodguessr',
        patterns: [
            /FoodGuessr/i,
            /🍔.*?(\d+)/i
        ],
        extract: (match, text) => {
            const scoreMatch = text.match(/(\d+)\s*\/\s*(\d+)/);
            const correct = scoreMatch ? parseInt(scoreMatch[1]) : null;
            const total = scoreMatch ? parseInt(scoreMatch[2]) : null;
            
            return {
                gameId: 'foodguessr',
                gameName: 'FoodGuessr',
                icon: '🍔',
                puzzleNumber: null,
                displayScore: correct !== null ? `${correct}/${total}` : 'Completed',
                success: true,
                perfect: correct === total,
                raw: {
                    correct,
                    total
                },
                contestPoints: correct && total 
                    ? Math.round((correct / total) * 100)
                    : 50,
                source: 'foodguessr',
                parsedAt: new Date()
            };
        }
    },
    
    // -------------------------------------------------------------------------
    // RB GAMES (Your Games)
    // -------------------------------------------------------------------------
    
    rungs: {
        id: 'rungs',
        name: 'Rungs',
        icon: '🪜',
        source: 'rb-games',
        patterns: [
            /Rungs\s+#?(\d+)/i,
            /🪜.*Rungs/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse Rungs-specific format
            const timeMatch = text.match(/(\d+):(\d+)/);
            const mistakesMatch = text.match(/(\d+)\s*mistake/i);
            
            let totalSeconds = null;
            if (timeMatch) {
                totalSeconds = parseInt(timeMatch[1]) * 60 + parseInt(timeMatch[2]);
            }
            
            const mistakes = mistakesMatch ? parseInt(mistakesMatch[1]) : 0;
            
            return {
                gameId: 'rungs',
                gameName: 'Rungs',
                icon: '🪜',
                puzzleNumber: puzzleNum,
                displayScore: totalSeconds 
                    ? `${timeMatch[1]}:${String(parseInt(timeMatch[2])).padStart(2, '0')}`
                    : 'Completed',
                success: true,
                perfect: mistakes === 0 && totalSeconds && totalSeconds < 60,
                raw: {
                    totalSeconds,
                    mistakes
                },
                contestPoints: totalSeconds 
                    ? ContestScoring.timeGame(totalSeconds, 90, 300) - (mistakes * 5)
                    : 70,
                source: 'rb-games',
                parsedAt: new Date()
            };
        }
    },
    
    slate: {
        id: 'slate',
        name: 'Slate',
        icon: '🪨',
        source: 'rb-games',
        patterns: [
            /Slate\s+#?(\d+)/i,
            /🪨.*Slate/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse Slate-specific format
            const scoreMatch = text.match(/(\d+)\/(\d+)/);
            const correct = scoreMatch ? parseInt(scoreMatch[1]) : null;
            const total = scoreMatch ? parseInt(scoreMatch[2]) : 5;
            
            return {
                gameId: 'slate',
                gameName: 'Slate',
                icon: '🪨',
                puzzleNumber: puzzleNum,
                displayScore: correct !== null ? `${correct}/${total}` : 'Completed',
                success: correct === total,
                perfect: correct === total,
                raw: {
                    correct,
                    total
                },
                contestPoints: correct !== null 
                    ? Math.round((correct / total) * 100)
                    : 70,
                source: 'rb-games',
                parsedAt: new Date()
            };
        }
    },
    
    quotle: {
        id: 'quotle',
        name: 'Quotle',
        icon: '💬',
        source: 'rb-games',
        patterns: [
            /Quotle\s+#?(\d+)/i,
            /💬.*Quotle/i
        ],
        extract: (match, text) => {
            const puzzleNum = match[1];
            
            // Parse Quotle format
            const guessMatch = text.match(/([1-6X])\/6/);
            const guesses = guessMatch ? guessMatch[1] : null;
            const failed = guesses === 'X';
            const modeMatch = text.match(/(Easy|Hard)\s*Mode/i);
            const mode = modeMatch ? modeMatch[1].toLowerCase() : 'easy';
            
            return {
                gameId: 'quotle',
                gameName: 'Quotle',
                icon: '💬',
                puzzleNumber: puzzleNum,
                displayScore: guesses ? `${guesses}/6` : 'Completed',
                success: !failed,
                perfect: guesses === '1',
                raw: {
                    guesses: failed ? 7 : parseInt(guesses) || null,
                    failed,
                    mode,
                    hardMode: mode === 'hard'
                },
                contestPoints: failed 
                    ? 0 
                    : guesses 
                        ? ContestScoring.guessGame(parseInt(guesses), 6, false) + (mode === 'hard' ? 10 : 0)
                        : 50,
                source: 'rb-games',
                parsedAt: new Date()
            };
        }
    },
    
    wordBoxing: {
        id: 'wordboxing',
        name: 'Word Boxing',
        icon: '🥊',
        source: 'rb-games',
        patterns: [
            /Word\s*Boxing/i,
            /🥊.*Boxing/i
        ],
        extract: (match, text) => {
            // Word Boxing is multiplayer, parse win/loss
            const resultMatch = text.match(/(Won|Lost|Draw)/i);
            const result = resultMatch ? resultMatch[1].toLowerCase() : 'completed';
            const scoreMatch = text.match(/(\d+)\s*-\s*(\d+)/);
            
            let myScore = null, oppScore = null;
            if (scoreMatch) {
                myScore = parseInt(scoreMatch[1]);
                oppScore = parseInt(scoreMatch[2]);
            }
            
            return {
                gameId: 'wordboxing',
                gameName: 'Word Boxing',
                icon: '🥊',
                puzzleNumber: null,
                displayScore: myScore !== null ? `${myScore}-${oppScore}` : result,
                success: result === 'won',
                perfect: result === 'won' && oppScore === 0,
                raw: {
                    result,
                    myScore,
                    oppScore,
                    isMultiplayer: true
                },
                contestPoints: result === 'won' ? 100 : result === 'draw' ? 50 : 25,
                source: 'rb-games',
                parsedAt: new Date()
            };
        }
    }
};

// ============================================================================
// MAIN PARSER CLASS
// ============================================================================

class ShareParser {
    constructor(customParsers = {}) {
        // Merge custom parsers with defaults
        this.parsers = { ...GameParsers, ...customParsers };
        
        // Build pattern index for fast matching
        this.patternIndex = this._buildPatternIndex();
    }
    
    _buildPatternIndex() {
        const index = [];
        for (const [id, parser] of Object.entries(this.parsers)) {
            for (const pattern of parser.patterns) {
                index.push({ pattern, parserId: id });
            }
        }
        return index;
    }
    
    /**
     * Parse share text and return normalized result
     * @param {string} text - Raw share text from clipboard
     * @returns {NormalizedResult|null} - Parsed result or null if no match
     */
    parse(text) {
        if (!text || typeof text !== 'string') return null;
        
        const trimmed = text.trim();
        
        // Try each pattern
        for (const { pattern, parserId } of this.patternIndex) {
            const match = trimmed.match(pattern);
            if (match) {
                const parser = this.parsers[parserId];
                try {
                    return parser.extract(match, trimmed);
                } catch (e) {
                    console.error(`Parser error for ${parserId}:`, e);
                    continue;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Detect which game a share text is from without full parsing
     * @param {string} text - Raw share text
     * @returns {Object|null} - { id, name, icon } or null
     */
    detectGame(text) {
        if (!text || typeof text !== 'string') return null;
        
        const trimmed = text.trim();
        
        for (const { pattern, parserId } of this.patternIndex) {
            if (pattern.test(trimmed)) {
                const parser = this.parsers[parserId];
                return {
                    id: parser.id,
                    name: parser.name,
                    icon: parser.icon
                };
            }
        }
        
        return null;
    }
    
    /**
     * Get all supported games
     * @returns {Array} - List of { id, name, icon, source }
     */
    getSupportedGames() {
        return Object.values(this.parsers).map(p => ({
            id: p.id,
            name: p.name,
            icon: p.icon,
            source: p.source
        }));
    }
    
    /**
     * Add or update a parser
     * @param {string} id - Game ID
     * @param {Object} parser - Parser config
     */
    addParser(id, parser) {
        this.parsers[id] = parser;
        this.patternIndex = this._buildPatternIndex();
    }
    
    /**
     * Convert parsed result to legacy GAME_PATTERNS format
     * For backwards compatibility with existing Game Shelf code
     * @param {NormalizedResult} result 
     * @returns {Object} - Legacy format { score, success }
     */
    toLegacyFormat(result) {
        if (!result) return null;
        return {
            score: result.displayScore,
            success: result.success
        };
    }
}

// ============================================================================
// EXPORTS (for module usage)
// ============================================================================

// For direct inclusion in HTML
if (typeof window !== 'undefined') {
    window.ShareParser = ShareParser;
    window.GameParsers = GameParsers;
    window.ContestScoring = ContestScoring;
}

// For Node.js/module environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ShareParser, GameParsers, ContestScoring };
}
