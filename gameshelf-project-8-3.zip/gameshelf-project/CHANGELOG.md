# Changelog

All notable changes to Game Shelf will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
<!-- Add changes here as they're developed -->

---

## [1.25.3] - 2026-01-14

### Added
- **Editable OCR Results Before Import**
  - All parsed values now shown in editable number input fields
  - Users can correct OCR errors before importing
  - Checkbox to include/exclude each game in multi-game import
  - Helper text: "✏️ Click any value to correct OCR errors"

### Technical
- `_formatEditableGameData()` - generates editable fields for multi-game view
- `_formatEditableResultData()` - generates editable fields for single-game view
- `_getEditedValues()` - reads current input field values on import
- Import now uses user-corrected values instead of raw OCR results

---

## [1.25.2] - 2026-01-14

### Fixed
- **Screenshot Parser for NYT Profile Format**
  - Position-based parsing for NYT "Me" profile screenshots
  - Numbers and labels on separate lines now handled correctly
  - OCR fixup for win percentages (e.g., "817" → 81% correction)

### Technical
- NYT Profile format: Game header → Numbers line → Labels on following lines
- `extractNytProfileGameData()` - new position-based extractor

---

## [1.25.0] - 2026-01-14

### Added
- **Screenshot Parser for Historical Data Import**
  - Upload game stats screenshots to backfill history
  - Uses Tesseract.js OCR for text recognition
  - Intelligent image preprocessing (grayscale, contrast, dark mode detection/inversion)
  - Auto-detects game type from screenshot content
  
- **Supported Games for Screenshot Import**
  - 🟩 Wordle Stats (played, win %, streaks, guess distribution)
  - 🔗 Connections Stats (solved, streaks)
  - 🧵 Strands Stats (solved, hints used, perfect games)
  - 🐝 Spelling Bee Stats (puzzles started, genius achieved, queen bees)
  - 📝 Mini Crossword Stats (solved, best/avg time, streak)
  - 📰 NYT Games Overall Stats (games played, day streak)

- **Wordle Guess Distribution Analyzer**
  - Visual bar detection for guess distribution
  - Scans for green horizontal bars in screenshot
  - Extracts relative distribution from bar widths

- **Screenshot Import UI**
  - Drag-and-drop upload modal
  - Real-time progress indicators during OCR
  - Preview uploaded image
  - Shows detected game type with confidence percentage
  - Displays extracted stats before import
  - Smart merge (only updates if imported values are higher)
  
- **Settings Menu Integration**
  - New "Import from Screenshot" option in Data section
  - Shows helper text about backfilling history

### Technical
- `ScreenshotTemplates` - game identifiers and regex patterns
- `ImagePreprocessor` - image loading, canvas conversion, OCR prep
- `WordleDistributionAnalyzer` - visual bar region detection
- `ScreenshotParser` - main parser with game detection and data extraction
- `ScreenshotImportUI` - full modal UI with drag/drop support
- Dynamic Tesseract.js loading (only loads when needed)

---

## [1.24.0] - 2026-01-14

### Added
- **Data Abstraction Layer (DataService)**
  - Designed for cloud sync, implemented local first
  - Transparent backend swap from localStorage to Firebase
  - Separate handling for account data (cloud) vs game data (local)
  - Ready for Phase 2 full cloud sync
  
- **Per-Game Tracking Source Configuration**
  - Users can declare where they primarily play each game (NYT iOS/Android, browser with/without extension, multiple places)
  - Entry method selection (auto-capture, paste share text, manual entry, screenshot import)
  - Settings accessible via ⚙️ button on game cards (appears on hover)
  - Setup badge (!) indicator for games needing tracking configuration
  - Cloud sync toggle (Pro feature, coming in Phase 2)
  - Daily goal inclusion toggle
  
- **Tracking Source Visual Indicators**
  - Game cards show tracking source icon (📱 🌐 🔀) in corner
  - Icons fade on hover to show settings button
  - Quick visual scan of where games are tracked
  
- **First-Play Tracking Setup Prompt**
  - When playing a game for the first time, prompts user to set tracking source
  - Quick one-tap buttons: Browser, iOS App, Android App, Multiple
  - "More Options" button for detailed settings
  - "Skip" option for users who want to configure later
  - Only shows once per game (tracked via setupPromptShown flag)

- **New Constants**
  - `TRACKING_SOURCES`: nyt-ios, nyt-android, browser-extension, browser-manual, multiple
  - `ENTRY_METHODS`: extension, share, manual, screenshot
- **gameSettings field** in userData model for per-game configuration

### Technical
- Game Tracking Settings modal with source/method selectors
- `needsTrackingSetup()`, `getGameTrackingSettings()`, `saveGameTrackingSettings()` functions
- Settings button added to both featured cards and regular game cards
- CSS for tracking modal, options, toggles, and badges

---

## [1.23.0] - 2026-01-14

### Added
- **Dual Currency System**: Complete economic overhaul
  - 🎫 **Tokens**: Free currency earned through play (no monetary value)
  - 🪙 **Coins**: Premium currency purchased only ($1 ≈ 1 Coin)
- **Game Shelf Pro Subscription**: 
  - Monthly: $9.99/mo for 10 Coins + 2x Token earnings + Pro badge
  - Annual: $99.99/yr for 120 Coins (save $20)
- **Age Verification Gate**: 18+ verification required for Coin purchases
- **New Wallet UI**: 
  - Dual currency display in header (Tokens + Coins)
  - Pro badge for subscribers
  - Updated wallet modal with both currencies
  - "How to Earn Tokens" and "How to Get Coins" sections
- **Subscription Modal**: Browse subscription benefits and tiers
- **Token Rewards System** (`TOKEN_REWARDS`):
  - Daily login: +50 Tokens
  - Game complete: +100 Tokens
  - 7-day streak: +500 Tokens
  - 30-day streak: +2,000 Tokens
  - Achievements: +250-1000 Tokens
  - New user bonus: +5,000 Tokens
  - Pro subscribers: 2x all Token earnings

### Changed
- **Coin Pricing**: 
  - Starter: $4.99 = 5 Coins
  - Plus: $9.99 = 11 Coins (+10% bonus)
  - Value: $24.99 = 28 Coins (+12% bonus)
- **Gift Pricing**: Now 1 Coin = $1 value
  - $15 Gift = 15 Coins
  - $30 Gift = 30 Coins
  - $50 Gift = 50 Coins
  - $75 Gift = 75 Coins
  - $100 Gift = 100 Coins
- Prize pool battles now use Coins (premium)
- Free battles use Tokens
- Virtual rewards use Tokens
- Physical gifts (Goody) use Coins exclusively
- Renamed all `earnCoins` for rewards to `earnTokens`
- Updated transaction history to show currency type

### Technical
- Added `userData.wallet.tokens` and `userData.wallet.coins` (dual balance)
- Added `userData.wallet.ageVerified` flag
- Added `userData.wallet.subscription` object
- Migration from old `balance` field to new `tokens` field
- New constants: `TOKEN_REWARDS`, `SUBSCRIPTION_TIERS`
- Updated `COIN_PACKS` with new pricing structure
- Added CSS for: `.currency-badges`, `.token-badge`, `.pro-badge`, `.wallet-dual-display`, `.age-verification-notice`, `.coin-pack-card`, `.subscription-benefits`, `.sub-tier-card`

---

## [1.22.0] - 2026-01-14

### Added
- **Goody Gift Tier System**: Replaced individual physical items with 5 Gift of Choice tiers
  - $15 tier - 50+ gift options
  - $30 tier - 100+ gift options (marked as Popular)
  - $50 tier - 150+ gift options
  - $75 tier - 200+ gift options
  - $100+ tier - 250+ gift options
- **Curated Preview Data** (`GOODY_TIER_PREVIEWS`): Shows category pills and featured items with brand names for each tier
- **Gift Tier Details Modal** (`showGiftTierDetails()`): Rich browsing experience with:
  - Tier header with value and product count
  - Category grid (Sweets, Coffee, Candles, Tech, etc.)
  - Featured items in 2-column layout
  - "How it Works" step-by-step guide
  - Pricing breakdown with balance check
- **Gift Tier Redemption Flow**: New `redeemGiftTier()` function with dedicated confirmation modal
- **Enhanced Catalog Display**: Tier cards with colored badges and "Powered by Goody" branding

### Changed
- Merch store now shows Gift Tiers instead of individual physical items
- "Browse" button on Gift Tiers opens new tier details modal

### Fixed
- Fixed file truncation issue (missing closing tags)
- Removed Cloudflare email protection script injection
- Fixed encoded email placeholder in profile section
- Improved merch modal flex layout for better scrolling

### Technical
- Added CSS styles for: `.goody-tier-card`, `.tier-badge`, `.goody-brand`, `.gift-tier-modal`, `.category-grid`, `.category-pill`, `.featured-grid`, `.featured-item`, `.hiw-steps`, `.step-num`, `.tier-pricing`, `.tp-row`

---

## [1.21.0] - 2026-01-14

### Added
- Initial Goody integration planning
- Gift of Choice concept implementation

---

## [1.20.0] - 2026-01-13

### Added
- Public tournaments system
- Tournament browsing and filtering

---

## [1.19.0] - 2026-01-12

### Added
- **Merch Store**: Complete store UI with tabs (All, Rewards, Gifts, Orders)
- **Virtual Rewards**: Profile frames, badges, and titles earned through battles
- **Physical Gifts**: Initial Goody items (Snack Box, Coffee Kit, Candles, etc.)
- **Order Tracking**: Order history and status display

### Changed
- Separated rewards (earned) from gifts (purchased)
- Updated pricing model: 600 coins per $1 of gift value

---

## [1.18.0] - 2026-01-11

### Added
- **Brain Battle Creation**: Full modal for creating 1v1 and group battles
- **Battle Configuration**: Game selection, duration, stakes options
- **Battle History**: Track past competitions and results

---

## [1.17.0] - 2026-01-10

### Added
- **Shelf Coins™ Wallet**: Balance display, transaction history
- **Coin Earning System**: Daily login (+5), game completion (+10), streak bonuses
- **Buy Coins Modal**: Coin pack purchasing UI (mock)

---

## [1.16.0] - 2026-01-09

### Added
- **Friends System**: Add friends, view friend activity
- **Activity Feed**: See what friends are playing
- **Leaderboards**: Compare stats with friends

---

## [1.15.0] - 2026-01-08

### Added
- **Chrome Extension Support**: Auto-capture game results
- **Extension Modal**: Installation instructions for multiple browsers

---

## [1.14.0] - 2026-01-07

### Added
- **Insights Tab**: Statistics and analytics
- **Weekly/Monthly views**: Historical performance tracking
- **Best day/game analysis**: Identify patterns

---

## [1.13.0] - 2026-01-06

### Added
- **Dark/Light Theme**: User-selectable appearance
- **Theme Persistence**: Saves preference to localStorage

---

## [1.12.0] - 2026-01-05

### Added
- **PWA Support**: Installable on mobile/desktop
- **Service Worker**: Offline functionality
- **App Manifest**: Icon, name, theme color

---

## [1.11.0] - 2026-01-04

### Added
- **Firebase Authentication**: Google sign-in
- **Cloud Sync**: Data syncs across devices
- **Profile System**: User profiles with stats

---

## [1.10.0] - 2026-01-03

### Added
- **Achievements System**: Unlock badges for milestones
- **Achievement Notifications**: Toast notifications on unlock

---

## [1.9.0] - 2026-01-02

### Added
- **Share Functionality**: Share daily results
- **Share Preview**: Visual card for sharing
- **Multiple Share Options**: Copy text, native share, image download

---

## [1.8.0] - 2026-01-01

### Added
- **Discover Tab**: Find new games to play
- **Game Categories**: Filter by type (word, logic, etc.)
- **Add Custom Games**: User-defined games

---

## [1.0.0] - 2025-12-25

### Added
- Initial release
- **Game Tracking**: Track daily puzzle completions
- **Streak System**: Build and maintain streaks
- **Featured Games**: Wordle, Connections, Mini Crossword, Strands
- **Local Storage**: Persist data in browser

---

## Version Numbering

- **Major (X.0.0)**: Breaking changes, major new features
- **Minor (0.X.0)**: New features, backward compatible
- **Patch (0.0.X)**: Bug fixes, small improvements

## Links

- [README](./README.md)
- [Architecture](./docs/ARCHITECTURE.md)
- [Feature Specs](./docs/FEATURES.md)
