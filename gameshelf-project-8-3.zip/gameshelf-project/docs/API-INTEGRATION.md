# API Integration Guide

## Goody Commerce API

### Overview

Goody enables gift fulfillment without managing inventory. Users redeem Shelf Coins for a "Gift of Choice" credit, then receive an email to select their gift from Goody's catalog.

### Current Status: Mock Implementation

The current implementation simulates the Goody flow:
1. User clicks "Redeem" on a Gift Tier
2. Coins are deducted
3. Order is created in `userData.merchOrders`
4. Confirmation modal shows "check your email"

### Production Integration

#### 1. Get API Credentials

Sign up at: https://business.ongoody.com

You'll receive:
- API Key (for authentication)
- Webhook secret (for order updates)

#### 2. API Endpoints

**Base URL**: `https://api.ongoody.com/v1`
**Sandbox**: `https://sandbox.api.ongoody.com/v1`

##### Create Gift Order

```javascript
POST /orders
Authorization: Bearer {API_KEY}
Content-Type: application/json

{
  "recipient_email": "user@example.com",
  "recipient_name": "John Doe",
  "amount_cents": 3000,  // $30 gift
  "message": "Thanks for being a Game Shelf champion! 🎮",
  "sender_name": "Game Shelf"
}
```

Response:
```json
{
  "id": "order_abc123",
  "gift_link": "https://ongoody.com/gift/abc123",
  "status": "pending",
  "amount_cents": 3000,
  "created_at": "2026-01-14T12:00:00Z"
}
```

##### Get Order Status

```javascript
GET /orders/{order_id}
Authorization: Bearer {API_KEY}
```

Response:
```json
{
  "id": "order_abc123",
  "status": "redeemed",  // pending, viewed, redeemed, shipped, delivered
  "gift_selected": "Blue Bottle Coffee Subscription",
  "tracking_number": "1Z999AA10123456784",
  "shipped_at": "2026-01-16T10:00:00Z"
}
```

#### 3. Webhook Events

Set up webhook endpoint to receive updates:

```javascript
POST /api/goody-webhook

// Verify signature
const signature = req.headers['x-goody-signature'];
const isValid = verifySignature(req.body, signature, WEBHOOK_SECRET);

// Handle events
switch (event.type) {
  case 'gift.viewed':
    // Recipient opened the gift link
    break;
  case 'gift.redeemed':
    // Recipient selected their gift
    updateOrder(event.order_id, { status: 'redeemed', gift: event.gift_name });
    break;
  case 'gift.shipped':
    // Gift has shipped
    updateOrder(event.order_id, { status: 'shipped', tracking: event.tracking });
    break;
  case 'gift.delivered':
    // Gift delivered
    updateOrder(event.order_id, { status: 'delivered' });
    break;
}
```

#### 4. Implementation in Game Shelf

Update `redeemGiftTier()`:

```javascript
async function redeemGiftTier(tierId) {
    const item = merchCatalog.find(m => m.id === tierId);
    if (!item) return;
    
    if (userData.wallet.balance < item.price) {
        showToast('Not enough coins!');
        return;
    }
    
    // Show loading state
    showLoadingModal('Creating your gift...');
    
    try {
        // Call Goody API
        const response = await fetch('https://api.ongoody.com/v1/orders', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${GOODY_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                recipient_email: currentUser.email,
                recipient_name: currentUser.displayName,
                amount_cents: item.goodyValue * 100,
                message: `Congratulations! You've redeemed a ${item.name}! 🎮`,
                sender_name: 'Game Shelf'
            })
        });
        
        const goodyOrder = await response.json();
        
        // Deduct coins only after successful API call
        spendCoins(item.price, `🎁 Redeemed: ${item.name}`);
        
        // Create local order record
        const order = {
            id: 'order_' + Date.now(),
            goodyOrderId: goodyOrder.id,
            goodyLink: goodyOrder.gift_link,
            itemId: item.id,
            itemName: item.name,
            price: item.price,
            goodyValue: item.goodyValue,
            status: 'pending',
            createdAt: Date.now()
        };
        
        merchOrders.push(order);
        saveMerchOrders();
        
        hideLoadingModal();
        showGiftTierConfirmation(order);
        
    } catch (error) {
        hideLoadingModal();
        showToast('Failed to create gift. Please try again.');
        console.error('Goody API error:', error);
    }
}
```

#### 5. Environment Configuration

```javascript
// config.js (or inline in gameshelf.html)
const CONFIG = {
    goody: {
        apiKey: process.env.GOODY_API_KEY || 'sandbox_key_xxx',
        baseUrl: process.env.NODE_ENV === 'production' 
            ? 'https://api.ongoody.com/v1'
            : 'https://sandbox.api.ongoody.com/v1',
        webhookSecret: process.env.GOODY_WEBHOOK_SECRET
    }
};
```

### Goody Gift Tier Mapping

| Game Shelf Tier | Coins | Goody Amount | API `amount_cents` |
|-----------------|-------|--------------|-------------------|
| $15 Gift | 9,000 | $15 | 1500 |
| $30 Gift | 18,000 | $30 | 3000 |
| $50 Gift | 30,000 | $50 | 5000 |
| $75 Gift | 45,000 | $75 | 7500 |
| $100+ Gift | 60,000 | $100 | 10000 |

---

## Firebase Configuration

### Current Setup

```javascript
const firebaseConfig = {
    apiKey: "AIzaSyBQVwn8vOrFTzLlm2MYIPBwgZV2xR9AuhM",
    authDomain: "word-boxing.firebaseapp.com",
    databaseURL: "https://word-boxing-default-rtdb.firebaseio.com",
    projectId: "word-boxing",
    storageBucket: "word-boxing.firebasestorage.app",
    messagingSenderId: "300155036194",
    appId: "1:300155036194:web:b35463e6f9fbb04d7fe07b"
};
```

### Database Rules

```json
{
  "rules": {
    "gameshelf": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "public": {
      "tournaments": {
        ".read": true,
        ".write": "auth != null"
      },
      "leaderboards": {
        ".read": true,
        ".write": "auth != null"
      }
    }
  }
}
```

---

## Future API Integrations

### Push Notifications (Firebase Cloud Messaging)

```javascript
// Request permission
const permission = await Notification.requestPermission();
if (permission === 'granted') {
    const token = await messaging.getToken();
    // Store token in user profile
}

// Send notification (server-side)
admin.messaging().send({
    token: userToken,
    notification: {
        title: '🔥 Streak at risk!',
        body: 'Complete your daily games to keep your streak!'
    }
});
```

### Payment Processing (Stripe)

For purchasing Shelf Coins:

```javascript
// Create checkout session
const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
        price: 'price_coins_5000',
        quantity: 1
    }],
    mode: 'payment',
    success_url: 'https://gameshelf.app/payment-success',
    cancel_url: 'https://gameshelf.app/payment-cancelled'
});

// Webhook for successful payment
app.post('/stripe-webhook', (req, res) => {
    const event = stripe.webhooks.constructEvent(
        req.body,
        req.headers['stripe-signature'],
        STRIPE_WEBHOOK_SECRET
    );
    
    if (event.type === 'checkout.session.completed') {
        // Add coins to user wallet
        const userId = event.data.object.client_reference_id;
        const coinsToAdd = getCoinsForPrice(event.data.object.amount_total);
        await addCoinsToUser(userId, coinsToAdd);
    }
});
```

---

## Testing

### Goody Sandbox

Use sandbox credentials for testing:
- Orders won't result in real shipments
- Test all flows before going live

### Firebase Emulator

```bash
firebase emulators:start
```

Test locally without affecting production data.
