# Data Sync Architecture

## Overview

Game Shelf faces a unique challenge: users play games across multiple platforms (iOS apps, Android apps, various browsers) but want unified tracking. This document outlines our phased approach to data synchronization.

## The Problem

| Scenario | Current Behavior | Desired Behavior |
|----------|------------------|------------------|
| Play Wordle in NYT iOS app | Game Shelf doesn't know | Tracked in Game Shelf |
| Log game on desktop browser | Only desktop has data | All devices have data |
| Buy Coins on mobile | Only mobile wallet updated | All devices show purchase |
| Add friend on tablet | Only tablet has friend | Friends synced everywhere |

### Why This Matters

1. **Paid Features**: Users who purchase Coins must see them on ALL devices
2. **Social Features**: Friends, battles, leaderboards require consistent data
3. **User Trust**: Inconsistent data = user frustration = churn
4. **Game Integrity**: Streaks and stats must be accurate

---

## Architecture Principles

### Design for Cloud, Start with Hybrid

```
┌─────────────────────────────────────────────────────────────────┐
│                        DESIGN PRINCIPLE                          │
│                                                                  │
│   "Every data access goes through an abstraction layer that     │
│    can swap between local and cloud storage transparently"      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Data Classification

All user data falls into two categories:

| Category | Examples | Sync Requirement | Phase 1 | Phase 2+ |
|----------|----------|------------------|---------|----------|
| **Account Data** | Wallet, subscription, friends, purchases, achievements | MUST sync | Cloud (Firebase) | Cloud |
| **Game Data** | Stats, history, streaks, daily results | SHOULD sync | Local + Source Declaration | Cloud (optional) |

---

## Data Model

### Complete User Object

```javascript
const UserData = {
    // ═══════════════════════════════════════════════════════════
    // IDENTITY (from Auth Provider)
    // ═══════════════════════════════════════════════════════════
    id: "firebase_uid_abc123",
    email: "user@example.com",
    displayName: "PlayerOne",
    photoURL: "https://...",
    providers: ["google.com"],
    createdAt: 1704067200000,
    lastLoginAt: 1705276800000,

    // ═══════════════════════════════════════════════════════════
    // ACCOUNT DATA (Always Cloud Synced)
    // ═══════════════════════════════════════════════════════════
    wallet: {
        tokens: 5000,           // Free currency (earned)
        coins: 15,              // Premium currency (purchased)
        ageVerified: true,      // 18+ verification for purchases
        transactions: [...],    // Last 50 transactions
        lastDailyBonus: "2026-01-14",
        streakBonuses: {}
    },

    subscription: {
        tier: "monthly",        // null | "monthly" | "annual"
        status: "active",       // "active" | "cancelled" | "expired"
        startedAt: 1704067200000,
        expiresAt: 1706745600000,
        lastCoinDistribution: "2026-01"
    },

    friends: {
        list: [
            { id: "friend_123", displayName: "Alice", addedAt: timestamp },
            { id: "friend_456", displayName: "Bob", addedAt: timestamp }
        ],
        pending: {
            incoming: [...],
            outgoing: [...]
        }
    },

    purchases: [
        { id: "purch_001", type: "coins", pack: "value", amount: 28, price: 24.99, timestamp: ... },
        { id: "purch_002", type: "subscription", tier: "monthly", price: 9.99, timestamp: ... }
    ],

    achievements: {
        unlocked: ["first_game", "week_streak", "social_butterfly"],
        progress: {
            "century_club": { current: 45, target: 100 },
            "perfect_month": { current: 12, target: 30 }
        }
    },

    // ═══════════════════════════════════════════════════════════
    // GAME CONFIGURATION (Cloud Synced)
    // ═══════════════════════════════════════════════════════════
    gameSettings: {
        "wordle": {
            enabled: true,
            trackingSource: "nyt-ios",           // See Tracking Sources below
            entryMethod: "manual",               // "extension" | "share" | "manual" | "screenshot"
            cloudSync: false,                    // Phase 2: sync game data to cloud
            notifications: true,
            goalEnabled: true
        },
        "connections": {
            enabled: true,
            trackingSource: "browser-extension",
            entryMethod: "extension",
            cloudSync: false,
            notifications: true,
            goalEnabled: true
        }
    },

    // ═══════════════════════════════════════════════════════════
    // GAME DATA (Local in Phase 1, Cloud Optional in Phase 2)
    // ═══════════════════════════════════════════════════════════
    stats: {
        "wordle": {
            played: 150,
            won: 142,
            currentStreak: 23,
            maxStreak: 45,
            lastPlayed: "2026-01-14",
            distribution: { 1: 5, 2: 20, 3: 45, 4: 50, 5: 18, 6: 4 },
            averageScore: 3.4
        },
        "connections": {
            played: 80,
            won: 65,
            perfectGames: 12,
            currentStreak: 5,
            maxStreak: 14,
            lastPlayed: "2026-01-14"
        }
    },

    history: {
        "wordle": {
            "2026-01-14": { score: 4, hardMode: false, timestamp: 1705276800000 },
            "2026-01-13": { score: 3, hardMode: false, timestamp: 1705190400000 },
            // ... last 365 days
        },
        "connections": {
            "2026-01-14": { score: 2, mistakes: 1, perfect: false, timestamp: ... },
            // ...
        }
    },

    // ═══════════════════════════════════════════════════════════
    // LOCAL PREFERENCES (Never Synced)
    // ═══════════════════════════════════════════════════════════
    preferences: {
        theme: "dark",
        hapticFeedback: true,
        soundEffects: false,
        compactView: false
    }
};
```

### Tracking Sources

Users declare where they primarily play each game:

```javascript
const TRACKING_SOURCES = {
    // NYT Games
    "nyt-ios": {
        label: "NYT App (iOS)",
        icon: "📱",
        entryMethods: ["manual", "share", "screenshot"],
        description: "You play on iPhone/iPad in the NYT app"
    },
    "nyt-android": {
        label: "NYT App (Android)",
        icon: "📱",
        entryMethods: ["manual", "share", "screenshot"],
        description: "You play on Android in the NYT app"
    },
    "browser-extension": {
        label: "Browser (with Extension)",
        icon: "🌐",
        entryMethods: ["extension"],
        description: "Extension auto-captures your results"
    },
    "browser-manual": {
        label: "Browser (no Extension)",
        icon: "🌐",
        entryMethods: ["manual", "share"],
        description: "You'll paste or enter results manually"
    },
    "multiple": {
        label: "Multiple Places",
        icon: "🔀",
        entryMethods: ["manual", "share", "screenshot"],
        description: "You play on different devices/apps"
    }
};

const ENTRY_METHODS = {
    "extension": {
        label: "Auto-capture",
        description: "Browser extension captures automatically",
        requiresExtension: true
    },
    "share": {
        label: "Share/Paste",
        description: "Paste your share text (e.g., Wordle 123 4/6)"
    },
    "manual": {
        label: "Manual Entry",
        description: "Enter your score manually"
    },
    "screenshot": {
        label: "Screenshot Import",
        description: "Import from screenshot (coming soon)",
        comingSoon: true
    }
};
```

---

## Data Service Abstraction

### Interface Definition

```javascript
/**
 * DataService Interface
 * All data access goes through this interface.
 * Implementations can be swapped without changing application code.
 */
const DataServiceInterface = {
    // ═══════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Initialize the data service
     * @param {string} userId - Authenticated user ID
     * @returns {Promise<void>}
     */
    async initialize(userId) {},

    /**
     * Clean up resources
     * @returns {Promise<void>}
     */
    async dispose() {},

    // ═══════════════════════════════════════════════════════════
    // ACCOUNT DATA (Always Cloud)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get complete account data
     * @returns {Promise<AccountData>}
     */
    async getAccount() {},

    /**
     * Update account data (partial update)
     * @param {Partial<AccountData>} updates
     * @returns {Promise<void>}
     */
    async updateAccount(updates) {},

    // ═══════════════════════════════════════════════════════════
    // WALLET (Always Cloud)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get wallet data
     * @returns {Promise<WalletData>}
     */
    async getWallet() {},

    /**
     * Add tokens (earned)
     * @param {number} amount
     * @param {string} reason
     * @returns {Promise<number>} New balance
     */
    async earnTokens(amount, reason) {},

    /**
     * Spend tokens
     * @param {number} amount
     * @param {string} reason
     * @returns {Promise<boolean>} Success
     */
    async spendTokens(amount, reason) {},

    /**
     * Add coins (purchased or earned)
     * @param {number} amount
     * @param {string} reason
     * @returns {Promise<number>} New balance
     */
    async earnCoins(amount, reason) {},

    /**
     * Spend coins
     * @param {number} amount
     * @param {string} reason
     * @returns {Promise<boolean>} Success
     */
    async spendCoins(amount, reason) {},

    // ═══════════════════════════════════════════════════════════
    // SUBSCRIPTION (Always Cloud)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get subscription status
     * @returns {Promise<SubscriptionData|null>}
     */
    async getSubscription() {},

    /**
     * Activate subscription
     * @param {string} tier - "monthly" | "annual"
     * @param {Object} purchaseDetails
     * @returns {Promise<void>}
     */
    async activateSubscription(tier, purchaseDetails) {},

    /**
     * Cancel subscription
     * @returns {Promise<void>}
     */
    async cancelSubscription() {},

    // ═══════════════════════════════════════════════════════════
    // FRIENDS (Always Cloud)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get friends list
     * @returns {Promise<FriendsData>}
     */
    async getFriends() {},

    /**
     * Send friend request
     * @param {string} friendCode
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async sendFriendRequest(friendCode) {},

    /**
     * Accept friend request
     * @param {string} requestId
     * @returns {Promise<void>}
     */
    async acceptFriendRequest(requestId) {},

    /**
     * Remove friend
     * @param {string} friendId
     * @returns {Promise<void>}
     */
    async removeFriend(friendId) {},

    // ═══════════════════════════════════════════════════════════
    // GAME SETTINGS (Cloud - affects all devices)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get settings for a game
     * @param {string} gameId
     * @returns {Promise<GameSettings>}
     */
    async getGameSettings(gameId) {},

    /**
     * Update game settings
     * @param {string} gameId
     * @param {Partial<GameSettings>} settings
     * @returns {Promise<void>}
     */
    async updateGameSettings(gameId, settings) {},

    /**
     * Set tracking source for a game
     * @param {string} gameId
     * @param {string} source - See TRACKING_SOURCES
     * @param {string} entryMethod - See ENTRY_METHODS
     * @returns {Promise<void>}
     */
    async setTrackingSource(gameId, source, entryMethod) {},

    // ═══════════════════════════════════════════════════════════
    // GAME DATA (Local Phase 1, Cloud Phase 2)
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Get stats for a game
     * @param {string} gameId
     * @returns {Promise<GameStats>}
     */
    async getGameStats(gameId) {},

    /**
     * Update stats for a game
     * @param {string} gameId
     * @param {Partial<GameStats>} stats
     * @returns {Promise<void>}
     */
    async updateGameStats(gameId, stats) {},

    /**
     * Get history for a game
     * @param {string} gameId
     * @param {number} days - Number of days to retrieve (default 365)
     * @returns {Promise<Object>} Date-keyed history
     */
    async getGameHistory(gameId, days = 365) {},

    /**
     * Log a game result
     * @param {string} gameId
     * @param {string} date - YYYY-MM-DD
     * @param {Object} result
     * @returns {Promise<void>}
     */
    async logGameResult(gameId, date, result) {},

    // ═══════════════════════════════════════════════════════════
    // SYNC CONTROL
    // ═══════════════════════════════════════════════════════════
    
    /**
     * Force sync all data
     * @returns {Promise<{success: boolean, errors: string[]}>}
     */
    async syncAll() {},

    /**
     * Get sync status
     * @returns {Promise<SyncStatus>}
     */
    async getSyncStatus() {},

    /**
     * Enable/disable cloud sync for game data
     * @param {string} gameId
     * @param {boolean} enabled
     * @returns {Promise<void>}
     */
    async setGameCloudSync(gameId, enabled) {}
};
```

---

## Phase 1 Implementation

### Storage Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                         PHASE 1                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────┐      ┌─────────────────────┐          │
│  │   Firebase Auth     │      │  Firebase Firestore │          │
│  │   (Identity)        │      │  (Account Data)     │          │
│  │                     │      │                     │          │
│  │  • Google Sign-In   │      │  • Wallet           │          │
│  │  • User ID          │      │  • Subscription     │          │
│  │  • Email            │      │  • Friends          │          │
│  │                     │      │  • Purchases        │          │
│  │                     │      │  • Achievements     │          │
│  │                     │      │  • Game Settings    │          │
│  └─────────────────────┘      └─────────────────────┘          │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    localStorage                          │   │
│  │                    (Game Data)                           │   │
│  │                                                          │   │
│  │  • Stats per game                                        │   │
│  │  • History per game                                      │   │
│  │  • Local preferences                                     │   │
│  │                                                          │   │
│  │  Key: gameshelf_stats_wordle                            │   │
│  │  Key: gameshelf_history_wordle                          │   │
│  │  Key: gameshelf_preferences                             │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Phase 1 Code Structure

```javascript
// services/DataService.js

class HybridDataService {
    constructor() {
        this.userId = null;
        this.firestore = null;
        this.accountCache = null;
        this.listeners = [];
    }

    async initialize(userId) {
        this.userId = userId;
        this.firestore = firebase.firestore();
        
        // Set up real-time listener for account data
        this.setupAccountListener();
        
        // Migrate any old localStorage data
        await this.migrateOldData();
    }

    // ═══════════════════════════════════════════════════════════
    // ACCOUNT DATA (Firestore)
    // ═══════════════════════════════════════════════════════════
    
    async getAccount() {
        if (this.accountCache) return this.accountCache;
        
        const doc = await this.firestore
            .collection('users')
            .doc(this.userId)
            .get();
            
        if (!doc.exists) {
            // Create new account
            await this.createNewAccount();
        }
        
        this.accountCache = doc.data();
        return this.accountCache;
    }

    async updateAccount(updates) {
        await this.firestore
            .collection('users')
            .doc(this.userId)
            .update({
                ...updates,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            
        // Cache is updated via listener
    }

    // ═══════════════════════════════════════════════════════════
    // WALLET (Firestore with transactions for safety)
    // ═══════════════════════════════════════════════════════════
    
    async earnTokens(amount, reason) {
        const userRef = this.firestore.collection('users').doc(this.userId);
        
        return this.firestore.runTransaction(async (transaction) => {
            const doc = await transaction.get(userRef);
            const wallet = doc.data().wallet || { tokens: 0, coins: 0 };
            
            const multiplier = doc.data().subscription?.status === 'active' ? 2 : 1;
            const finalAmount = amount * multiplier;
            
            const newBalance = (wallet.tokens || 0) + finalAmount;
            
            const newTransaction = {
                type: 'earn',
                currency: 'tokens',
                amount: finalAmount,
                reason: reason + (multiplier > 1 ? ' (2x Pro)' : ''),
                timestamp: Date.now()
            };
            
            transaction.update(userRef, {
                'wallet.tokens': newBalance,
                'wallet.transactions': firebase.firestore.FieldValue.arrayUnion(newTransaction)
            });
            
            return newBalance;
        });
    }

    async spendCoins(amount, reason) {
        const userRef = this.firestore.collection('users').doc(this.userId);
        
        return this.firestore.runTransaction(async (transaction) => {
            const doc = await transaction.get(userRef);
            const wallet = doc.data().wallet || { tokens: 0, coins: 0 };
            
            if ((wallet.coins || 0) < amount) {
                throw new Error('Insufficient coins');
            }
            
            const newBalance = wallet.coins - amount;
            
            const newTransaction = {
                type: 'spend',
                currency: 'coins',
                amount: amount,
                reason: reason,
                timestamp: Date.now()
            };
            
            transaction.update(userRef, {
                'wallet.coins': newBalance,
                'wallet.transactions': firebase.firestore.FieldValue.arrayUnion(newTransaction)
            });
            
            return true;
        });
    }

    // ═══════════════════════════════════════════════════════════
    // GAME DATA (localStorage)
    // ═══════════════════════════════════════════════════════════
    
    async getGameStats(gameId) {
        const key = `gameshelf_stats_${this.userId}_${gameId}`;
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : this.getDefaultStats(gameId);
    }

    async updateGameStats(gameId, stats) {
        const key = `gameshelf_stats_${this.userId}_${gameId}`;
        const existing = await this.getGameStats(gameId);
        const merged = { ...existing, ...stats, updatedAt: Date.now() };
        localStorage.setItem(key, JSON.stringify(merged));
    }

    async getGameHistory(gameId, days = 365) {
        const key = `gameshelf_history_${this.userId}_${gameId}`;
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : {};
    }

    async logGameResult(gameId, date, result) {
        // Update history
        const history = await this.getGameHistory(gameId);
        history[date] = { ...result, timestamp: Date.now() };
        
        const historyKey = `gameshelf_history_${this.userId}_${gameId}`;
        localStorage.setItem(historyKey, JSON.stringify(history));
        
        // Update stats
        await this.recalculateStats(gameId, history);
        
        // Award tokens
        await this.earnTokens(100, `🎮 Completed ${gameId}`);
    }

    // ═══════════════════════════════════════════════════════════
    // TRACKING SOURCE
    // ═══════════════════════════════════════════════════════════
    
    async setTrackingSource(gameId, source, entryMethod) {
        await this.updateAccount({
            [`gameSettings.${gameId}.trackingSource`]: source,
            [`gameSettings.${gameId}.entryMethod`]: entryMethod
        });
    }
}

// Export singleton
export const DataService = new HybridDataService();
```

---

## Phase 2 Implementation (Future)

### What Changes

```
┌─────────────────────────────────────────────────────────────────┐
│                         PHASE 2                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   Firebase Firestore                     │   │
│  │                   (ALL User Data)                        │   │
│  │                                                          │   │
│  │  users/{userId}/                                         │   │
│  │    ├── account          (wallet, subscription, etc.)    │   │
│  │    ├── friends          (friend list, requests)          │   │
│  │    ├── achievements     (unlocked, progress)             │   │
│  │    ├── gameSettings     (per-game configuration)         │   │
│  │    ├── stats/           (per-game stats subcollection)   │   │
│  │    │   ├── wordle                                        │   │
│  │    │   ├── connections                                   │   │
│  │    │   └── ...                                           │   │
│  │    └── history/         (per-game history subcollection) │   │
│  │        ├── wordle                                        │   │
│  │        ├── connections                                   │   │
│  │        └── ...                                           │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    localStorage                          │   │
│  │                    (Cache + Offline)                     │   │
│  │                                                          │   │
│  │  • Cached copy of cloud data                            │   │
│  │  • Pending sync queue                                    │   │
│  │  • Local preferences only                                │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Migration from Phase 1 to Phase 2

```javascript
async function migrateToPhase2(userId) {
    const localStats = {};
    const localHistory = {};
    
    // Gather all local game data
    for (const gameId of SUPPORTED_GAMES) {
        const statsKey = `gameshelf_stats_${userId}_${gameId}`;
        const historyKey = `gameshelf_history_${userId}_${gameId}`;
        
        const stats = localStorage.getItem(statsKey);
        const history = localStorage.getItem(historyKey);
        
        if (stats) localStats[gameId] = JSON.parse(stats);
        if (history) localHistory[gameId] = JSON.parse(history);
    }
    
    // Upload to Firestore
    const batch = firestore.batch();
    
    for (const [gameId, stats] of Object.entries(localStats)) {
        const ref = firestore
            .collection('users').doc(userId)
            .collection('stats').doc(gameId);
        batch.set(ref, stats, { merge: true });
    }
    
    for (const [gameId, history] of Object.entries(localHistory)) {
        const ref = firestore
            .collection('users').doc(userId)
            .collection('history').doc(gameId);
        batch.set(ref, history, { merge: true });
    }
    
    await batch.commit();
    
    // Mark migration complete
    await firestore.collection('users').doc(userId).update({
        migratedToPhase2: true,
        migratedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    
    // Clear local storage (keep as cache)
    console.log('Migration complete. Local data retained as cache.');
}
```

---

## Conflict Resolution

When users play on multiple devices, conflicts can occur:

### Strategy: Last Write Wins + Merge

```javascript
function resolveConflict(local, remote, field) {
    switch (field) {
        // Numeric high-water marks: take highest
        case 'maxStreak':
        case 'played':
        case 'won':
            return Math.max(local, remote);
        
        // Current state: take most recent
        case 'currentStreak':
        case 'lastPlayed':
            return local.timestamp > remote.timestamp ? local : remote;
        
        // History: merge by date
        case 'history':
            return { ...remote, ...local }; // Local overwrites same dates
        
        // Wallet: ALWAYS trust server
        case 'tokens':
        case 'coins':
            return remote; // Server is source of truth
        
        default:
            // Default: last write wins
            return local.timestamp > remote.timestamp ? local : remote;
    }
}
```

---

## Security Rules (Firestore)

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      // Subcollections inherit parent permissions
      match /stats/{gameId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      
      match /history/{gameId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
    
    // Friends can read limited profile info
    match /users/{userId}/public {
      allow read: if request.auth != null;
    }
    
    // Leaderboards are public read
    match /leaderboards/{leaderboardId} {
      allow read: if true;
      allow write: if false; // Only cloud functions can write
    }
  }
}
```

---

## Cost Considerations

### Phase 1 Costs (Hybrid)

| Service | Usage | Estimated Cost |
|---------|-------|----------------|
| Firebase Auth | Free tier | $0 |
| Firestore Reads | ~50 reads/user/day | ~$0.001/user/day |
| Firestore Writes | ~10 writes/user/day | ~$0.002/user/day |
| **Total** | | **~$0.10/user/month** |

### Phase 2 Costs (Full Cloud)

| Service | Usage | Estimated Cost |
|---------|-------|----------------|
| Firebase Auth | Free tier | $0 |
| Firestore Reads | ~200 reads/user/day | ~$0.004/user/day |
| Firestore Writes | ~50 writes/user/day | ~$0.009/user/day |
| Firestore Storage | ~10KB/user | ~$0.001/user/month |
| **Total** | | **~$0.40/user/month** |

### Break-even Analysis

At 10,000 MAU:
- Phase 1: ~$1,000/month
- Phase 2: ~$4,000/month

Revenue needed to cover Phase 2:
- 400 Pro subscribers @ $9.99 = $3,996/month ✓

---

## Implementation Checklist

### Phase 1 (Current Sprint)

- [ ] Create `DataService` abstraction layer
- [ ] Implement `HybridDataService` class
- [ ] Add tracking source field to data model
- [ ] Create tracking source selector UI
- [ ] Migrate wallet operations to use DataService
- [ ] Migrate friend operations to use DataService
- [ ] Add user-scoped localStorage keys
- [ ] Test multi-browser scenarios
- [ ] Document data backup/export feature

### Phase 2 (Future)

- [ ] Create `CloudDataService` class
- [ ] Build migration script
- [ ] Add offline queue for writes
- [ ] Implement conflict resolution
- [ ] Add real-time sync listeners
- [ ] Build sync status indicator UI
- [ ] Add manual sync button
- [ ] Performance optimization (batching, caching)

---

## Appendix: Tracking Source UI Mockups

### Game Settings Modal

```
┌─────────────────────────────────────────────────────────────┐
│  ⚙️ Wordle Settings                                    [X]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📍 Where do you primarily play Wordle?                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ○ 📱 NYT App (iOS)                                  │   │
│  │ ○ 📱 NYT App (Android)                              │   │
│  │ ● 🌐 Browser with Extension (auto-capture)          │   │
│  │ ○ 🌐 Browser without Extension                      │   │
│  │ ○ 🔀 I play in multiple places                      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ℹ️ This helps us understand how to track your games.       │
│     You can always log results manually regardless of       │
│     your selection.                                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  📊 How should we capture your results?                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ● ✨ Auto-capture (Extension detects completion)    │   │
│  │ ○ 📋 Paste share text                               │   │
│  │ ○ ✏️ Manual entry                                    │   │
│  │ ○ 📷 Screenshot import (coming soon)                │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  ☁️ Cloud Sync                                              │
│                                                             │
│  [ ] Sync game data across all my devices                   │
│      ⭐ Pro feature - keeps stats identical everywhere      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Cancel]                              [Save Settings]      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### First-Time Game Setup Flow

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    🎮 Adding Wordle                         │
│                                                             │
│         Let's set up tracking for accurate stats            │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│         ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│         │   📱    │  │   🌐    │  │   🔀    │             │
│         │  App    │  │ Browser │  │Multiple │             │
│         └────┬────┘  └────┬────┘  └────┬────┘             │
│              │            │            │                    │
│              ▼            ▼            ▼                    │
│         ┌─────────────────────────────────────┐            │
│         │  Where do you usually play Wordle?  │            │
│         └─────────────────────────────────────┘            │
│                                                             │
│  ┌───────────────────────────────────────────────────┐     │
│  │  📱  NYT Games App                                │     │
│  │      iPhone, iPad, or Android                     │     │
│  └───────────────────────────────────────────────────┘     │
│                                                             │
│  ┌───────────────────────────────────────────────────┐     │
│  │  🌐  Web Browser                                  │     │
│  │      nytimes.com/games/wordle                     │     │
│  └───────────────────────────────────────────────────┘     │
│                                                             │
│  ┌───────────────────────────────────────────────────┐     │
│  │  🔀  Both / Multiple Devices                      │     │
│  │      I switch between app and browser             │     │
│  └───────────────────────────────────────────────────┘     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Skip for now]                          [Continue →]       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

*Document Version: 1.0*
*Last Updated: 2026-01-14*
*Author: Game Shelf Development Team*
