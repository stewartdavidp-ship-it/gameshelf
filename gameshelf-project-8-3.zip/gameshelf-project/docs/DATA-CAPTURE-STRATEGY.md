# Game Shelf: Data Capture & Partner Ecosystem Strategy

## Executive Summary

This document outlines the strategy for capturing game results across different data sources, managing game placements (paid and organic), and building an indie partner ecosystem. The goal is to make Game Shelf the central hub for daily puzzle tracking while creating sustainable revenue streams.

---

## 1. Data Capture Architecture

### Tiered Approach

```
┌─────────────────────────────────────────────────────────────────────┐
│                    GAME RESULT DATA SOURCES                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  TIER 1: Share Text Parsing (Available Now)                        │
│  ├── User pastes share text from any game                          │
│  ├── Universal parser handles 20+ game formats                     │
│  ├── Normalized scoring for contests (0-100 scale)                 │
│  └── Works with: NYT, LA Times, indie games, etc.                  │
│                                                                     │
│  TIER 2: Browser Extension (Current)                               │
│  ├── Auto-capture when game completes                              │
│  ├── Best UX but requires install                                  │
│  └── Works for NYT Games already                                   │
│                                                                     │
│  TIER 3: Indie Game API Partners (Build Now)                       │
│  ├── Direct API integration with partner games                     │
│  ├── In exchange for featured placement                            │
│  └── Mutual benefit: they get users, we get reliable data          │
│                                                                     │
│  TIER 4: Major Publisher API (Future Dream)                        │
│  ├── Prove traffic value first (need analytics)                    │
│  ├── NYT, WaPo, LA Times partnerships                              │
│  └── Long-term: Two-way data sharing                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Share Text Parser Capabilities

**File:** `share-parser.js`

Currently supports:
- NYT Games: Wordle, Connections, Strands, Spelling Bee, Mini, Letterboxed, Tiles, Vertex
- Wordle Variants: Quordle, Octordle
- Geography: Worldle, Globle, Tradle
- Trivia/Knowledge: Framed, Nerdle, Redactle, Semantle
- Sports: Immaculate Grid
- Fun: Costcodle, FoodGuessr
- RB Games: Rungs, Slate, Quotle, Word Boxing

Each parser extracts:
- `displayScore` - Human-readable (e.g., "4/6", "2:15")
- `contestPoints` - Normalized 0-100 for fair comparisons
- `raw` - Detailed data for analytics (guesses, time, mistakes, etc.)
- `success` / `perfect` - Binary flags for achievements

---

## 2. Placement Framework

### Placement Types

| Type | Location | Revenue Model | Purpose |
|------|----------|---------------|---------|
| **Featured** | Top grid (hero) | Internal / Partner | RB Games + top partners |
| **Sponsored** | Above featured, labeled | Paid CPM | Advertising revenue |
| **API Partner** | Featured rotation | Data exchange | Indie partnerships |
| **Discovery** | Below My Games | Free/Earned | Recommendations |
| **Catalog** | Browse All | Free | Full game directory |

### Slot Limits

- **Featured:** 4 slots (RB Games priority)
- **Sponsored:** 2 slots (clearly labeled)
- **API Partner:** 6 slots (rotating)
- **Discovery:** 8 slots (algorithmic)
- **Catalog:** Unlimited

### Revenue Projections

Assuming 10K DAU:
- Sponsored (2 slots × $5 CPM × 10K impressions/day) = **$100/day**
- At 100K DAU: **$1,000/day** or ~$30K/month

---

## 3. Indie Partner API Specification

### Value Proposition for Indies

> "Get featured placement on Game Shelf in exchange for API access to your game's result data."

### What We Need From Partners

```javascript
// GET /api/gameshelf/results
// Returns user's game results

Request:
  Header: X-GameShelf-Partner-Key: {api_key}
  Params: userToken, date (optional), limit (optional)

Response:
{
  "puzzleNumber": "123",
  "date": "2025-01-14",
  "score": "4/6",
  "success": true,
  "perfect": false,
  "raw": { /* game-specific data */ },
  "timestamp": "2025-01-14T12:00:00Z"
}
```

### What Partners Get

1. **Placement Benefits**
   - Featured rotation (6 slots shared)
   - 90-day renewable placement
   - Cross-game contest integration

2. **Analytics Dashboard**
   - Daily active users referred
   - Click-through rates
   - Competition engagement metrics

3. **Traffic Referrals**
   - Deep links with UTM tracking
   - Referral dashboard
   - Attribution reporting

### Privacy & Security

- User tokens are anonymized hashes (`gs_user_{hash}`)
- Never share emails or personal info
- Partners only see aggregated analytics
- GDPR/CCPA compliant data handling

---

## 4. Long-term Vision: Publisher Partnerships

### The Dream: Native Competition Integration

> Allow game companies to pull competition info so that when a user logs into Wordle, it shows they're in an active Game Shelf competition.

### Path to Get There

1. **Phase 1: Prove Value (Now - 6 months)**
   - Track referral traffic meticulously
   - Show engagement lift for featured games
   - Build case study with indie partners

2. **Phase 2: Approach Publishers (6-12 months)**
   - Present traffic data to NYT Games, WaPo, etc.
   - Propose read-only API access (we read their data)
   - Highlight competition engagement benefits

3. **Phase 3: Two-Way Integration (12-18 months)**
   - If we prove value, propose widget/notification
   - "You're in a Game Shelf competition! Tap to see standings"
   - Revenue share model for premium features

### Realistic Assessment

- NYT will likely **never** give API access (they're protective)
- Share text parsing will remain primary method for major publishers
- Focus energy on indie partnerships where we have leverage

---

## 5. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-2)
- [x] Build universal share parser (`share-parser.js`)
- [x] Create partner framework (`partner-framework.js`)
- [ ] Integrate parser into Game Shelf (replace GAME_PATTERNS)
- [ ] Add partner admin UI

### Phase 2: Indie Outreach (Weeks 3-4)
- [ ] Create partner landing page
- [ ] Document API specification
- [ ] Identify 10 target indie games
- [ ] Reach out to developers

### Phase 3: Monetization (Weeks 5-6)
- [ ] Build sponsored placement system
- [ ] Add impression/click tracking
- [ ] Create advertiser dashboard
- [ ] Set up payment processing

### Phase 4: Scale (Ongoing)
- [ ] Grow DAU through content/social
- [ ] Expand partner network
- [ ] Build analytics for traffic proof
- [ ] Approach major publishers with data

---

## 6. Key Metrics to Track

### User Engagement
- DAU / MAU
- Games logged per user per day
- Share text paste success rate
- Extension install rate

### Partner Health
- Click-through rate (CTR) by placement
- Conversion rate (click → play)
- API sync success rate
- Partner retention (90-day renewal)

### Revenue
- Sponsored impressions delivered
- CPM rates achieved
- Partner LTV (if paid tiers later)

---

## 7. Technical Integration Guide

### Replacing GAME_PATTERNS with ShareParser

```javascript
// Old way (in gameshelf.html)
const GAME_PATTERNS = [
    { id: 'wordle', pattern: /.../, extract: (match) => {...} },
    // ...
];

// New way (with share-parser.js)
const parser = new ShareParser();

function parseShareText() {
    const text = document.getElementById('parse-input').value.trim();
    const result = parser.parse(text);
    
    if (result) {
        // result.gameId, result.displayScore, result.contestPoints, etc.
        logGameResult(result);
    }
}
```

### Using PartnerManager for Placements

```javascript
const partners = new PartnerManager();

// Get featured games for hero section
const featured = partners.getFeaturedGames();

// Get sponsored (with tracking)
const sponsored = partners.getSponsoredGames();
sponsored.forEach(game => partners.trackImpression(game.id));

// Track clicks
function onGameClick(gameId) {
    partners.trackClick(gameId);
    window.open(game.url, '_blank');
}
```

---

## 8. Files Created

| File | Purpose |
|------|---------|
| `share-parser.js` | Universal share text parser with 20+ games |
| `partner-framework.js` | Placement management, sponsorships, indie API |
| `docs/DATA-CAPTURE-STRATEGY.md` | This document |

---

## Next Steps

1. **Integrate ShareParser** into gameshelf.html (replace existing GAME_PATTERNS)
2. **Add PartnerManager** for dynamic placement loading
3. **Build admin UI** for managing partners
4. **Create partner outreach materials** (landing page, pitch deck)
5. **Start tracking referral analytics** to prove value

---

*Last updated: January 2025*
