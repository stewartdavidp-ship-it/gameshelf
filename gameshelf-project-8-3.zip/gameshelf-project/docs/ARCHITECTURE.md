# Game Shelf Architecture

## Overview

Game Shelf is a single-file Progressive Web App (PWA) built with vanilla JavaScript. This document describes the technical architecture and key design decisions.

## File Structure

### Single-File Design

The main application (`gameshelf.html`) contains:
- HTML structure
- CSS styles (in `<style>` tag)
- JavaScript logic (in `<script>` tag)

**Rationale**: Simplifies deployment, enables easy sharing, and reduces HTTP requests.

### Supporting Files

```
gameshelf.html   # Main application (~11,000 lines)
manifest.json    # PWA manifest
sw.js           # Service worker
```

## Application Architecture

### Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                        User Interface                        │
├─────────────────────────────────────────────────────────────┤
│  Games Tab │ Insights │ Battle │ Community │ Settings       │
└──────┬──────────┬─────────┬────────┬──────────┬─────────────┘
       │          │         │        │          │
       ▼          ▼         ▼        ▼          ▼
┌─────────────────────────────────────────────────────────────┐
│                    State Management                          │
│                      (userData object)                       │
└──────────────────────────┬──────────────────────────────────┘
                           │
           ┌───────────────┼───────────────┐
           ▼               ▼               ▼
    ┌────────────┐  ┌────────────┐  ┌────────────┐
    │ localStorage│  │  Firebase  │  │  External  │
    │   (local)  │  │  (cloud)   │  │   APIs     │
    └────────────┘  └────────────┘  └────────────┘
```

### State Management

All application state is stored in the `userData` object:

```javascript
userData = {
    // User identity
    name: string,
    registered: boolean,
    
    // Game data
    games: Game[],              // Custom games
    stats: { [gameId]: GameStats },
    
    // Social
    friends: Friend[],
    friendRequests: FriendRequest[],
    
    // Economy
    wallet: {
        balance: number,
        transactions: Transaction[],
        lastDailyBonus: string,
        streakBonuses: { [key]: string }
    },
    
    // Competitions
    battles: Battle[],
    tournaments: Tournament[],
    
    // Merch
    ownedMerch: string[],
    merchOrders: Order[],
    
    // Achievements
    achievements: { [id]: string },
    
    // Settings
    theme: 'dark' | 'light',
    notifications: boolean
}
```

### Persistence Strategy

1. **Primary**: localStorage (immediate, offline-capable)
2. **Secondary**: Firebase Realtime Database (cloud sync)

```javascript
function saveData() {
    localStorage.setItem('gameShelfData', JSON.stringify(userData));
    if (isFirebaseReady && currentUser) {
        syncToCloud();
    }
}
```

## Key Subsystems

### 1. Game Tracking

**Components**:
- `FEATURED_GAMES[]` - Built-in game definitions
- `userData.games[]` - User-added games
- `userData.stats{}` - Per-game statistics

**Functions**:
- `logGame(gameId)` - Record completion
- `updateStreak(gameId)` - Calculate streak
- `renderGames()` - Display game cards

### 2. Shelf Coins™ Economy

**Components**:
- `userData.wallet` - Balance and transactions

**Functions**:
- `earnCoins(amount, reason)` - Add coins
- `spendCoins(amount, reason)` - Deduct coins
- `checkStreakBonuses()` - Award streak bonuses

**Earning Sources**:
| Action | Coins |
|--------|-------|
| Daily login | +5 |
| Complete game | +10 |
| 7-day streak | +50 |
| 30-day streak | +200 |
| Achievement | +25-100 |
| Battle win | Prize pool |

### 3. Brain Battles™

**Types**:
- `challenge` - 1v1 friend competition
- `group` - Multi-player competition
- `tournament` - Public competition

**State Machine**:
```
pending → active → completed
           ↓
       cancelled
```

**Scoring**:
- Wordle: 7 - guesses (max 6 points)
- Connections: mistakes avoided (max 4 points)
- Binary games: 1 point for completion

### 4. Merch Store

**Categories**:
- `virtual` - Earned rewards (frames, badges, titles)
- `physical` - Purchasable gifts (Goody tiers)

**Goody Integration**:
```
User redeems coins
        ↓
Create order in userData
        ↓
[Future] Call Goody API
        ↓
User receives email with gift link
        ↓
User selects gift on Goody
        ↓
Goody ships gift
```

### 5. Firebase Integration

**Services Used**:
- Authentication (Google sign-in)
- Realtime Database (data sync)

**Data Structure**:
```
gameshelf/
  {userId}/
    profile: { name, email, photoURL }
    games: { ... }
    stats: { ... }
    wallet: { ... }
    friends: { ... }
```

**Sync Strategy**:
- Write: Immediate to localStorage, debounced to Firebase
- Read: localStorage first, then merge from Firebase

## UI Architecture

### Tab System

```
┌─────────────────────────────────────────┐
│  🎮 Games  │ 📊 Insights │ ⚔️ Battle │ 👥 Community │
└─────────────────────────────────────────┘
```

Each tab has:
- HTML container (hidden by default)
- Render function (`renderGames()`, `renderInsights()`, etc.)
- Tab switch handler (`switchTab(tabName)`)

### Modal System

Modals use consistent pattern:
```html
<div class="modal-overlay" id="modal-name">
    <div class="modal">
        <!-- Content -->
    </div>
</div>
```

```javascript
function showModal() {
    document.getElementById('modal-name').classList.add('active');
}

function closeModal() {
    document.getElementById('modal-name').classList.remove('active');
}
```

### Toast Notifications

```javascript
function showToast(message, duration = 3000) {
    // Create toast element
    // Auto-dismiss after duration
}
```

## Performance Considerations

### Lazy Loading
- Tab content rendered on-demand
- Modals created dynamically when opened

### Debouncing
- Cloud sync debounced to prevent excessive writes
- Render functions throttled during rapid updates

### Memory Management
- Transaction history capped at 50 items
- Chat messages capped at 50 items
- Old data pruned periodically

## Security

### Firebase Rules
```json
{
  "rules": {
    "gameshelf": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    }
  }
}
```

### Client-Side
- No sensitive data in localStorage
- API keys are Firebase (restricted by domain)
- User input escaped before display

## Future Considerations

### Potential Improvements
1. **Code splitting**: Separate CSS/JS files
2. **Build system**: Webpack/Vite for optimization
3. **TypeScript**: Type safety
4. **Testing**: Unit and integration tests
5. **State management**: Consider Redux/Zustand if complexity grows

### API Integrations Planned
1. **Goody Commerce API**: Gift fulfillment
2. **Push notifications**: Engagement reminders
3. **Analytics**: Usage tracking
