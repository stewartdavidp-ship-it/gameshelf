# Game Shelf Features

## Feature Status Legend

- ✅ Complete
- 🚧 In Progress
- 📋 Planned
- ❌ Deprecated

---

## Core Features

### Game Tracking ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Featured games list | ✅ | 1.0.0 | Wordle, Connections, Mini, Strands, etc. |
| Custom game adding | ✅ | 1.8.0 | User can add any daily game |
| Manual logging | ✅ | 1.0.0 | Click to mark complete |
| Auto-logging (extension) | ✅ | 1.15.0 | Chrome extension captures results |
| Streak tracking | ✅ | 1.0.0 | Consecutive day tracking |
| Score parsing | ✅ | 1.15.0 | Extract scores from share text |

### Statistics & Insights ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Daily summary | ✅ | 1.14.0 | Games played today |
| Weekly view | ✅ | 1.14.0 | 7-day history |
| Monthly view | ✅ | 1.14.0 | 30-day history |
| Best streak tracking | ✅ | 1.14.0 | Per-game and overall |
| Completion rate | ✅ | 1.14.0 | Success percentage |

---

## Social Features

### Friends System ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Add friends | ✅ | 1.16.0 | Via username/email |
| Friend requests | ✅ | 1.16.0 | Accept/decline flow |
| Friend list | ✅ | 1.16.0 | View all friends |
| Remove friends | ✅ | 1.16.0 | Unfriend option |
| Activity feed | ✅ | 1.16.0 | See friend completions |

### Leaderboards ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Friends leaderboard | ✅ | 1.16.0 | Compare with friends |
| Streak leaderboard | ✅ | 1.16.0 | Longest streaks |
| Games played leaderboard | ✅ | 1.16.0 | Most active players |

### Sharing ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Share as text | ✅ | 1.9.0 | Copy to clipboard |
| Native share | ✅ | 1.9.0 | Mobile share sheet |
| Share as image | ✅ | 1.9.0 | Download PNG |

---

## Competition System

### Brain Battles™ ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| 1v1 challenges | ✅ | 1.18.0 | Challenge specific friend |
| Group battles | ✅ | 1.18.0 | 2-20 players |
| Game selection | ✅ | 1.18.0 | Pick which games count |
| Duration options | ✅ | 1.18.0 | 1 day to 1 month |
| Coin wagers | ✅ | 1.18.0 | Bet Shelf Coins |
| Battle history | ✅ | 1.18.0 | Past competitions |

### Public Tournaments 🚧

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Tournament listing | ✅ | 1.20.0 | Browse available |
| Last Person Standing | ✅ | 1.20.0 | Elimination mode |
| High Score mode | ✅ | 1.20.0 | Cumulative points |
| Entry fees | ✅ | 1.20.0 | Coin cost to enter |
| Prize pools | ✅ | 1.20.0 | Winner takes pot |
| Real-time updates | 📋 | - | Live elimination feed |
| Tournament creation | 📋 | - | User-created tournaments |

---

## Economy System

### Shelf Coins™ ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Wallet display | ✅ | 1.17.0 | Balance in header |
| Earn from gameplay | ✅ | 1.17.0 | +10 per game |
| Daily login bonus | ✅ | 1.17.0 | +5 per day |
| Streak bonuses | ✅ | 1.17.0 | +50/+200 at milestones |
| Achievement bonuses | ✅ | 1.17.0 | +25-100 per unlock |
| Transaction history | ✅ | 1.17.0 | Full log |
| Buy coins (UI) | ✅ | 1.17.0 | Mock purchase flow |
| Buy coins (payment) | 📋 | - | Stripe/IAP integration |

### Merch Store ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Store UI | ✅ | 1.19.0 | Browse items |
| Virtual rewards | ✅ | 1.19.0 | Frames, badges, titles |
| Goody Gift Tiers | ✅ | 1.22.0 | $15-$100+ tiers |
| Tier browsing modal | ✅ | 1.22.0 | Category/item preview |
| Order tracking | ✅ | 1.19.0 | Order history |
| Goody API integration | 📋 | - | Real fulfillment |

---

## Platform Features

### PWA ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Installable | ✅ | 1.12.0 | Add to home screen |
| Offline support | ✅ | 1.12.0 | Service worker |
| App manifest | ✅ | 1.12.0 | Icon, colors, name |

### Authentication ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Google sign-in | ✅ | 1.11.0 | Firebase Auth |
| Profile display | ✅ | 1.11.0 | Name, photo, email |
| Cloud sync | ✅ | 1.11.0 | Cross-device data |

### Settings ✅

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Dark/Light theme | ✅ | 1.13.0 | User preference |
| Export data | ✅ | 1.13.0 | Download JSON |
| Reset data | ✅ | 1.13.0 | Clear all data |
| Re-run setup | ✅ | 1.13.0 | Reconfigure games |

---

## Planned Features

### Near-term (v1.23-1.25)

| Feature | Priority | Notes |
|---------|----------|-------|
| Goody API integration | High | Real gift fulfillment |
| Push notifications | Medium | Engagement reminders |
| Tournament creation | Medium | User-hosted events |
| Achievement gallery | Low | View all achievements |

### Mid-term (v1.26-1.30)

| Feature | Priority | Notes |
|---------|----------|-------|
| Teams/Groups | Medium | Persistent groups |
| Seasons | Medium | Monthly resets |
| Premium tier | Low | Ad-free, bonuses |
| Custom themes | Low | User color picks |

### Long-term (v2.0+)

| Feature | Priority | Notes |
|---------|----------|-------|
| Mobile app | Medium | React Native |
| API for developers | Low | Third-party integrations |
| Game publisher portal | Low | Official game support |

---

## Deprecated Features

| Feature | Removed | Reason |
|---------|---------|--------|
| Individual Goody items | v1.22.0 | Replaced with Gift Tiers |

---

## Feature Requests

Track user-requested features here:

1. [ ] Calendar view of completions
2. [ ] Game difficulty ratings
3. [ ] Friend suggestions
4. [ ] Competition spectator mode
5. [ ] Streak freeze (skip days)
