/**
 * GAME SHELF - Smart Tracking Module
 * Version: 1.0.0
 * 
 * Handles:
 * - Platform/browser auto-detection
 * - Onboarding flow
 * - Deep link launching (app vs browser)
 * - Extension promotion
 * - Per-game tracking preferences
 */

// ============================================================================
// PLATFORM DETECTION
// ============================================================================

const PlatformDetector = {
    /**
     * Detect user's platform, browser, and capabilities
     * @returns {Object} Detection results
     */
    detect() {
        const ua = navigator.userAgent;
        const platform = navigator.platform || '';
        
        const result = {
            // Platform
            isMobile: /iPhone|iPad|iPod|Android/i.test(ua),
            isTablet: /iPad|Android(?!.*Mobile)/i.test(ua),
            isDesktop: !/iPhone|iPad|iPod|Android/i.test(ua),
            isIOS: /iPhone|iPad|iPod/i.test(ua),
            isAndroid: /Android/i.test(ua),
            isMac: /Mac/i.test(platform),
            isWindows: /Win/i.test(platform),
            
            // Browser
            isChrome: /Chrome/i.test(ua) && !/Edg/i.test(ua),
            isSafari: /Safari/i.test(ua) && !/Chrome/i.test(ua),
            isFirefox: /Firefox/i.test(ua),
            isEdge: /Edg/i.test(ua),
            
            // Capabilities
            canInstallExtension: false,
            canUseShareSheet: false,
            canUsePWA: false,
            canDeepLink: false,
            
            // Raw
            userAgent: ua,
            platform: platform
        };
        
        // Determine capabilities
        result.canInstallExtension = result.isChrome && result.isDesktop;
        result.canUseShareSheet = result.isMobile && 'share' in navigator;
        result.canUsePWA = 'serviceWorker' in navigator;
        result.canDeepLink = result.isMobile;
        
        // Detect if running as PWA
        result.isPWA = window.matchMedia('(display-mode: standalone)').matches ||
                       window.navigator.standalone === true;
        
        return result;
    },
    
    /**
     * Get friendly description of detected platform
     * @param {Object} detection - Result from detect()
     * @returns {Object} Friendly labels
     */
    describe(detection) {
        let platform = 'Unknown';
        let browser = 'Unknown';
        let icon = '💻';
        
        if (detection.isIOS) {
            platform = detection.isTablet ? 'iPad' : 'iPhone';
            icon = '📱';
        } else if (detection.isAndroid) {
            platform = detection.isTablet ? 'Android Tablet' : 'Android Phone';
            icon = '📱';
        } else if (detection.isMac) {
            platform = 'Mac';
            icon = '💻';
        } else if (detection.isWindows) {
            platform = 'Windows';
            icon = '💻';
        }
        
        if (detection.isChrome) browser = 'Chrome';
        else if (detection.isSafari) browser = 'Safari';
        else if (detection.isFirefox) browser = 'Firefox';
        else if (detection.isEdge) browser = 'Edge';
        
        return { platform, browser, icon };
    },
    
    /**
     * Get recommended tracking setup based on detection
     * @param {Object} detection 
     * @returns {Object} Recommendations
     */
    getRecommendations(detection) {
        const recommendations = {
            primaryMethod: 'share',
            showExtensionPromo: false,
            deepLinkSupported: false,
            setupSteps: []
        };
        
        if (detection.isDesktop) {
            if (detection.isChrome) {
                recommendations.primaryMethod = 'extension';
                recommendations.showExtensionPromo = true;
                recommendations.setupSteps = [
                    'Install the Game Shelf Chrome extension',
                    'Play your games normally',
                    'Results are captured automatically!'
                ];
            } else {
                recommendations.primaryMethod = 'share';
                recommendations.setupSteps = [
                    'Play your games in the browser',
                    'After finishing, click "Share" in the game',
                    'Paste your results here'
                ];
            }
        } else if (detection.isMobile) {
            recommendations.primaryMethod = 'share';
            recommendations.deepLinkSupported = true;
            
            if (detection.isIOS) {
                recommendations.setupSteps = [
                    'Play in the NYT Games app or browser',
                    'Tap "Share" after finishing',
                    'Share to Game Shelf or copy & paste'
                ];
            } else {
                recommendations.setupSteps = [
                    'Play in your preferred app or browser',
                    'Tap "Share" after finishing',
                    'Copy and paste your results here'
                ];
            }
        }
        
        return recommendations;
    }
};

// ============================================================================
// DEEP LINK DATABASE
// ============================================================================

/**
 * Deep link configurations for launching games
 * Supports: iOS Universal Links, Android App Links, and fallback URLs
 */
const DeepLinks = {
    // NYT Games
    'wordle': {
        name: 'Wordle',
        ios: {
            appScheme: 'nytimes://games/wordle',
            universalLink: 'https://www.nytimes.com/games/wordle',
            appStoreId: '1234567890' // NYT Crossword app
        },
        android: {
            appScheme: 'intent://games/wordle#Intent;scheme=nytimes;package=com.nytimes.crossword;end',
            playStoreId: 'com.nytimes.crossword'
        },
        web: 'https://www.nytimes.com/games/wordle/index.html'
    },
    
    'connections': {
        name: 'Connections',
        ios: {
            appScheme: 'nytimes://games/connections',
            universalLink: 'https://www.nytimes.com/games/connections'
        },
        android: {
            appScheme: 'intent://games/connections#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/games/connections'
    },
    
    'strands': {
        name: 'Strands',
        ios: {
            appScheme: 'nytimes://games/strands',
            universalLink: 'https://www.nytimes.com/games/strands'
        },
        android: {
            appScheme: 'intent://games/strands#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/games/strands'
    },
    
    'spelling-bee': {
        name: 'Spelling Bee',
        ios: {
            appScheme: 'nytimes://games/spelling-bee',
            universalLink: 'https://www.nytimes.com/puzzles/spelling-bee'
        },
        android: {
            appScheme: 'intent://puzzles/spelling-bee#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/puzzles/spelling-bee'
    },
    
    'mini': {
        name: 'Mini Crossword',
        ios: {
            appScheme: 'nytimes://games/mini',
            universalLink: 'https://www.nytimes.com/crosswords/game/mini'
        },
        android: {
            appScheme: 'intent://crosswords/game/mini#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/crosswords/game/mini'
    },
    
    'letterboxed': {
        name: 'Letter Boxed',
        ios: {
            appScheme: 'nytimes://puzzles/letter-boxed',
            universalLink: 'https://www.nytimes.com/puzzles/letter-boxed'
        },
        android: {
            appScheme: 'intent://puzzles/letter-boxed#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/puzzles/letter-boxed'
    },
    
    'tiles': {
        name: 'Tiles',
        ios: {
            appScheme: 'nytimes://puzzles/tiles',
            universalLink: 'https://www.nytimes.com/puzzles/tiles'
        },
        android: {
            appScheme: 'intent://puzzles/tiles#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/puzzles/tiles'
    },
    
    'vertex': {
        name: 'Vertex',
        ios: {
            appScheme: 'nytimes://puzzles/vertex',
            universalLink: 'https://www.nytimes.com/puzzles/vertex'
        },
        android: {
            appScheme: 'intent://puzzles/vertex#Intent;scheme=nytimes;package=com.nytimes.crossword;end'
        },
        web: 'https://www.nytimes.com/puzzles/vertex'
    },
    
    // Standalone games (web only typically)
    'quordle': {
        name: 'Quordle',
        web: 'https://www.merriam-webster.com/games/quordle/'
    },
    
    'octordle': {
        name: 'Octordle',
        web: 'https://octordle.com/'
    },
    
    'worldle': {
        name: 'Worldle',
        web: 'https://worldle.teuteuf.fr/'
    },
    
    'globle': {
        name: 'Globle',
        web: 'https://globle-game.com/'
    },
    
    'tradle': {
        name: 'Tradle',
        web: 'https://oec.world/en/tradle/'
    },
    
    'framed': {
        name: 'Framed',
        web: 'https://framed.wtf/'
    },
    
    'nerdle': {
        name: 'Nerdle',
        web: 'https://nerdlegame.com/'
    },
    
    'redactle': {
        name: 'Redactle',
        web: 'https://redactle.net/'
    },
    
    'semantle': {
        name: 'Semantle',
        web: 'https://semantle.com/'
    },
    
    'immaculate-grid': {
        name: 'Immaculate Grid',
        ios: {
            appScheme: null,
            universalLink: 'https://www.immaculategrid.com/'
        },
        web: 'https://www.immaculategrid.com/'
    },
    
    'costcodle': {
        name: 'Costcodle',
        web: 'https://costcodle.com/'
    },
    
    // RB Games (your games - web only)
    'rungs': {
        name: 'Rungs',
        web: 'https://stewartdavidp-ship-it.github.io/Rungstest/'
    },
    
    'slate': {
        name: 'Slate',
        web: 'https://stewartdavidp-ship-it.github.io/Slate/'
    },
    
    'quotle': {
        name: 'Quotle',
        web: 'https://stewartdavidp-ship-it.github.io/Quotle/'
    },
    
    'wordboxing': {
        name: 'Word Boxing',
        web: 'https://stewartdavidp-ship-it.github.io/WordBoxing/'
    }
};

// ============================================================================
// SMART LAUNCHER
// ============================================================================

const SmartLauncher = {
    /**
     * Launch a game based on user's preferences
     * @param {string} gameId - Game identifier
     * @param {string} fallbackUrl - Fallback URL if no deep link
     * @param {Object} userPrefs - User's tracking preferences
     * @returns {Promise<boolean>} - Whether launch was successful
     */
    async launch(gameId, fallbackUrl, userPrefs = {}) {
        const detection = PlatformDetector.detect();
        const deepLink = DeepLinks[gameId];
        const trackingSource = userPrefs.trackingSource || 'browser-manual';
        
        console.log('🚀 SmartLauncher:', { gameId, trackingSource, detection: PlatformDetector.describe(detection) });
        
        // Determine launch strategy
        const strategy = this._determineLaunchStrategy(gameId, trackingSource, detection, deepLink);
        
        console.log('📋 Launch strategy:', strategy);
        
        // Execute launch
        return await this._executeLaunch(strategy, fallbackUrl);
    },
    
    /**
     * Determine the best launch strategy
     */
    _determineLaunchStrategy(gameId, trackingSource, detection, deepLink) {
        const strategy = {
            method: 'web', // 'web', 'app-scheme', 'universal-link', 'intent'
            url: null,
            fallbackUrl: deepLink?.web || null,
            tryDeepLink: false
        };
        
        // If user specifically set to play in app
        const playsInApp = ['nyt-ios', 'nyt-android'].includes(trackingSource);
        
        if (playsInApp && deepLink) {
            if (detection.isIOS && deepLink.ios) {
                // Try iOS deep link
                strategy.method = 'universal-link';
                strategy.url = deepLink.ios.universalLink || deepLink.ios.appScheme;
                strategy.tryDeepLink = true;
            } else if (detection.isAndroid && deepLink.android) {
                // Try Android intent
                strategy.method = 'intent';
                strategy.url = deepLink.android.appScheme;
                strategy.tryDeepLink = true;
            }
        }
        
        // Fallback to web
        if (!strategy.url) {
            strategy.method = 'web';
            strategy.url = deepLink?.web || strategy.fallbackUrl;
        }
        
        return strategy;
    },
    
    /**
     * Execute the launch strategy
     */
    async _executeLaunch(strategy, fallbackUrl) {
        const url = strategy.url || fallbackUrl;
        
        if (!url) {
            console.error('No URL to launch');
            return false;
        }
        
        if (strategy.tryDeepLink && strategy.method !== 'web') {
            // Try deep link with fallback
            return await this._tryDeepLinkWithFallback(strategy.url, strategy.fallbackUrl || fallbackUrl);
        } else {
            // Just open the URL
            window.open(url, '_blank');
            return true;
        }
    },
    
    /**
     * Try deep link, fall back to web if app not installed
     */
    async _tryDeepLinkWithFallback(deepLinkUrl, fallbackUrl) {
        return new Promise((resolve) => {
            const start = Date.now();
            let launched = false;
            
            // Set up visibility change listener
            const handleVisibilityChange = () => {
                if (document.hidden) {
                    // App opened successfully
                    launched = true;
                    cleanup();
                    resolve(true);
                }
            };
            
            const cleanup = () => {
                document.removeEventListener('visibilitychange', handleVisibilityChange);
                clearTimeout(fallbackTimeout);
            };
            
            document.addEventListener('visibilitychange', handleVisibilityChange);
            
            // Set fallback timeout
            const fallbackTimeout = setTimeout(() => {
                if (!launched) {
                    cleanup();
                    console.log('Deep link failed, opening web fallback');
                    window.open(fallbackUrl, '_blank');
                    resolve(false);
                }
            }, 2500); // Wait 2.5s before falling back
            
            // Try to open deep link
            console.log('Attempting deep link:', deepLinkUrl);
            
            // Use different methods based on URL type
            if (deepLinkUrl.startsWith('intent://')) {
                // Android intent
                window.location.href = deepLinkUrl;
            } else if (deepLinkUrl.startsWith('http')) {
                // Universal link - use window.location for iOS
                window.location.href = deepLinkUrl;
            } else {
                // Custom scheme
                const iframe = document.createElement('iframe');
                iframe.style.display = 'none';
                iframe.src = deepLinkUrl;
                document.body.appendChild(iframe);
                setTimeout(() => iframe.remove(), 1000);
            }
        });
    },
    
    /**
     * Check if a game has app support
     */
    hasAppSupport(gameId) {
        const deepLink = DeepLinks[gameId];
        return deepLink && (deepLink.ios || deepLink.android);
    },
    
    /**
     * Get available launch options for a game
     */
    getLaunchOptions(gameId) {
        const deepLink = DeepLinks[gameId];
        const detection = PlatformDetector.detect();
        
        const options = [];
        
        // Web is always available
        if (deepLink?.web) {
            options.push({
                id: 'web',
                label: 'Open in Browser',
                icon: '🌐',
                available: true
            });
        }
        
        // iOS app
        if (deepLink?.ios && detection.isIOS) {
            options.push({
                id: 'ios-app',
                label: 'Open in App',
                icon: '📱',
                available: true
            });
        }
        
        // Android app
        if (deepLink?.android && detection.isAndroid) {
            options.push({
                id: 'android-app',
                label: 'Open in App',
                icon: '📱',
                available: true
            });
        }
        
        return options;
    }
};

// ============================================================================
// ONBOARDING FLOW
// ============================================================================

const OnboardingFlow = {
    STORAGE_KEY: 'gameshelf_onboarding',
    
    /**
     * Check if onboarding is needed
     */
    isNeeded() {
        const data = this._loadData();
        return !data.completed;
    },
    
    /**
     * Get current onboarding state
     */
    getState() {
        return this._loadData();
    },
    
    /**
     * Start or resume onboarding
     */
    start(containerElement) {
        const detection = PlatformDetector.detect();
        const description = PlatformDetector.describe(detection);
        const recommendations = PlatformDetector.getRecommendations(detection);
        
        const state = this._loadData();
        state.detection = detection;
        state.step = state.step || 1;
        
        this._renderStep(containerElement, state, description, recommendations);
    },
    
    /**
     * Render current onboarding step
     */
    _renderStep(container, state, description, recommendations) {
        const step = state.step;
        
        let html = '';
        
        switch (step) {
            case 1:
                html = this._renderWelcomeStep(description, state.detection);
                break;
            case 2:
                html = this._renderPlatformConfirmStep(description, state.detection);
                break;
            case 3:
                if (state.detection.canInstallExtension) {
                    html = this._renderExtensionStep();
                } else {
                    html = this._renderCaptureMethodStep(state.detection, recommendations);
                }
                break;
            case 4:
                html = this._renderCompleteStep(recommendations);
                break;
            default:
                this._complete();
                return;
        }
        
        container.innerHTML = `
            <div class="onboarding-modal">
                <div class="onboarding-progress">
                    <div class="onboarding-progress-bar" style="width: ${(step / 4) * 100}%"></div>
                </div>
                <div class="onboarding-content">
                    ${html}
                </div>
            </div>
        `;
        
        // Bind event handlers
        this._bindEvents(container, state);
    },
    
    _renderWelcomeStep(description, detection) {
        return `
            <div class="onboarding-step">
                <div class="onboarding-icon">🎮</div>
                <h2>Welcome to Game Shelf!</h2>
                <p class="onboarding-subtitle">Your personal daily puzzle hub</p>
                
                <div class="onboarding-detected">
                    <div class="detected-badge">
                        <span class="detected-icon">${description.icon}</span>
                        <span class="detected-text">
                            Detected: <strong>${description.platform}</strong> with <strong>${description.browser}</strong>
                        </span>
                    </div>
                </div>
                
                <p class="onboarding-description">
                    Let's set up the best way to track your game results. This takes about 30 seconds.
                </p>
                
                <div class="onboarding-actions">
                    <button class="btn btn-primary btn-large" data-action="next">
                        Get Started →
                    </button>
                    <button class="btn btn-text" data-action="skip">
                        Skip setup
                    </button>
                </div>
            </div>
        `;
    },
    
    _renderPlatformConfirmStep(description, detection) {
        const platforms = [
            { id: 'desktop-chrome', icon: '💻', label: 'Computer (Chrome)', checked: detection.isDesktop && detection.isChrome },
            { id: 'desktop-other', icon: '💻', label: 'Computer (Safari/Firefox/Edge)', checked: detection.isDesktop && !detection.isChrome },
            { id: 'ios', icon: '📱', label: 'iPhone / iPad', checked: detection.isIOS },
            { id: 'android', icon: '📱', label: 'Android', checked: detection.isAndroid },
            { id: 'multiple', icon: '🔀', label: 'I use multiple devices', checked: false }
        ];
        
        return `
            <div class="onboarding-step">
                <h2>Where do you play?</h2>
                <p class="onboarding-subtitle">We detected ${description.platform}, but you can change this</p>
                
                <div class="platform-options">
                    ${platforms.map(p => `
                        <label class="platform-option ${p.checked ? 'selected' : ''}" data-platform="${p.id}">
                            <input type="radio" name="platform" value="${p.id}" ${p.checked ? 'checked' : ''}>
                            <span class="platform-icon">${p.icon}</span>
                            <span class="platform-label">${p.label}</span>
                            <span class="platform-check">✓</span>
                        </label>
                    `).join('')}
                </div>
                
                <div class="onboarding-actions">
                    <button class="btn btn-secondary" data-action="back">← Back</button>
                    <button class="btn btn-primary" data-action="next">Continue →</button>
                </div>
            </div>
        `;
    },
    
    _renderExtensionStep() {
        return `
            <div class="onboarding-step">
                <div class="onboarding-icon">✨</div>
                <h2>Auto-Capture Results</h2>
                <p class="onboarding-subtitle">The easiest way to track your games</p>
                
                <div class="extension-promo">
                    <div class="extension-preview">
                        <img src="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 60'><rect fill='%231a1a2e' width='100' height='60'/><text x='50' y='35' text-anchor='middle' fill='%23f4d35e' font-size='12'>Extension Preview</text></svg>" alt="Extension preview">
                    </div>
                    
                    <div class="extension-benefits">
                        <div class="benefit-item">
                            <span class="benefit-icon">🎯</span>
                            <span>Results captured automatically when you finish</span>
                        </div>
                        <div class="benefit-item">
                            <span class="benefit-icon">⚡</span>
                            <span>No copying or pasting required</span>
                        </div>
                        <div class="benefit-item">
                            <span class="benefit-icon">🔒</span>
                            <span>Private - only you see your results</span>
                        </div>
                    </div>
                </div>
                
                <div class="onboarding-actions">
                    <button class="btn btn-primary btn-large" data-action="install-extension">
                        🧩 Install Extension
                    </button>
                    <button class="btn btn-text" data-action="next">
                        I'll paste results manually instead
                    </button>
                </div>
                
                <div class="onboarding-actions" style="margin-top: 10px;">
                    <button class="btn btn-secondary" data-action="back">← Back</button>
                </div>
            </div>
        `;
    },
    
    _renderCaptureMethodStep(detection, recommendations) {
        const methods = [];
        
        if (detection.isMobile) {
            methods.push({
                id: 'share-sheet',
                icon: '📤',
                title: 'Share from Game',
                description: 'Tap "Share" in your game app, then share to Game Shelf',
                recommended: true
            });
        }
        
        methods.push({
            id: 'paste',
            icon: '📋',
            title: 'Copy & Paste',
            description: 'Copy your share text and paste it here',
            recommended: !detection.isMobile
        });
        
        if (detection.isMobile && detection.canUsePWA) {
            methods.push({
                id: 'pwa',
                icon: '📲',
                title: 'Add to Home Screen',
                description: 'Install Game Shelf for easier sharing',
                recommended: false
            });
        }
        
        return `
            <div class="onboarding-step">
                <h2>How to Log Results</h2>
                <p class="onboarding-subtitle">Choose your preferred method</p>
                
                <div class="capture-methods">
                    ${methods.map(m => `
                        <div class="capture-method ${m.recommended ? 'recommended' : ''}" data-method="${m.id}">
                            ${m.recommended ? '<span class="recommended-badge">Recommended</span>' : ''}
                            <span class="method-icon">${m.icon}</span>
                            <div class="method-info">
                                <div class="method-title">${m.title}</div>
                                <div class="method-desc">${m.description}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <div class="onboarding-actions">
                    <button class="btn btn-secondary" data-action="back">← Back</button>
                    <button class="btn btn-primary" data-action="next">Continue →</button>
                </div>
            </div>
        `;
    },
    
    _renderCompleteStep(recommendations) {
        return `
            <div class="onboarding-step">
                <div class="onboarding-icon">🎉</div>
                <h2>You're All Set!</h2>
                <p class="onboarding-subtitle">Here's how to log your first result</p>
                
                <div class="setup-steps">
                    ${recommendations.setupSteps.map((step, i) => `
                        <div class="setup-step">
                            <span class="step-number">${i + 1}</span>
                            <span class="step-text">${step}</span>
                        </div>
                    `).join('')}
                </div>
                
                <div class="onboarding-actions">
                    <button class="btn btn-primary btn-large" data-action="complete">
                        Start Playing! 🎮
                    </button>
                </div>
            </div>
        `;
    },
    
    /**
     * Bind click handlers for onboarding actions
     */
    _bindEvents(container, state) {
        container.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this._handleAction(action, container, state);
            });
        });
        
        // Platform selection
        container.querySelectorAll('.platform-option').forEach(opt => {
            opt.addEventListener('click', (e) => {
                container.querySelectorAll('.platform-option').forEach(o => o.classList.remove('selected'));
                opt.classList.add('selected');
                opt.querySelector('input').checked = true;
                state.selectedPlatform = opt.dataset.platform;
                this._saveData(state);
            });
        });
    },
    
    _handleAction(action, container, state) {
        const detection = PlatformDetector.detect();
        const description = PlatformDetector.describe(detection);
        const recommendations = PlatformDetector.getRecommendations(detection);
        
        switch (action) {
            case 'next':
                state.step++;
                this._saveData(state);
                this._renderStep(container, state, description, recommendations);
                break;
                
            case 'back':
                state.step = Math.max(1, state.step - 1);
                this._saveData(state);
                this._renderStep(container, state, description, recommendations);
                break;
                
            case 'skip':
                this._complete();
                container.innerHTML = '';
                if (typeof closeOnboardingModal === 'function') {
                    closeOnboardingModal();
                }
                break;
                
            case 'complete':
                this._complete();
                container.innerHTML = '';
                if (typeof closeOnboardingModal === 'function') {
                    closeOnboardingModal();
                }
                break;
                
            case 'install-extension':
                // Open Chrome Web Store
                window.open('https://chrome.google.com/webstore/detail/game-shelf/YOUR_EXTENSION_ID', '_blank');
                state.extensionPrompted = true;
                this._saveData(state);
                break;
        }
    },
    
    _complete() {
        const state = this._loadData();
        state.completed = true;
        state.completedAt = new Date().toISOString();
        this._saveData(state);
        
        // Dispatch event for other components
        window.dispatchEvent(new CustomEvent('onboarding-complete', { detail: state }));
    },
    
    _loadData() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            return data ? JSON.parse(data) : {};
        } catch (e) {
            return {};
        }
    },
    
    _saveData(data) {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.error('Failed to save onboarding state:', e);
        }
    },
    
    /**
     * Reset onboarding (for testing or re-running)
     */
    reset() {
        localStorage.removeItem(this.STORAGE_KEY);
    }
};

// ============================================================================
// USER PREFERENCES MANAGER
// ============================================================================

const TrackingPreferences = {
    STORAGE_KEY: 'gameshelf_tracking_prefs',
    
    /**
     * Get user's global tracking preferences
     */
    getGlobal() {
        const data = this._loadData();
        return data.global || {
            primaryPlatform: null,
            browser: null,
            mobileOS: null,
            extensionInstalled: false,
            preferredMethod: 'share'
        };
    },
    
    /**
     * Set global tracking preferences
     */
    setGlobal(prefs) {
        const data = this._loadData();
        data.global = { ...this.getGlobal(), ...prefs };
        this._saveData(data);
        return data.global;
    },
    
    /**
     * Get tracking preferences for a specific game
     */
    getForGame(gameId) {
        const data = this._loadData();
        const global = this.getGlobal();
        const gamePrefs = data.games?.[gameId] || {};
        
        // Merge with global defaults
        return {
            trackingSource: gamePrefs.trackingSource || this._inferTrackingSource(global),
            entryMethod: gamePrefs.entryMethod || global.preferredMethod || 'share',
            launchInApp: gamePrefs.launchInApp ?? this._shouldLaunchInApp(gameId, global),
            ...gamePrefs
        };
    },
    
    /**
     * Set tracking preferences for a specific game
     */
    setForGame(gameId, prefs) {
        const data = this._loadData();
        if (!data.games) data.games = {};
        data.games[gameId] = { ...this.getForGame(gameId), ...prefs };
        this._saveData(data);
        return data.games[gameId];
    },
    
    /**
     * Infer tracking source from global preferences
     */
    _inferTrackingSource(global) {
        if (global.extensionInstalled) return 'browser-extension';
        if (global.mobileOS === 'ios') return 'nyt-ios';
        if (global.mobileOS === 'android') return 'nyt-android';
        if (global.primaryPlatform === 'desktop') return 'browser-manual';
        return 'multiple';
    },
    
    /**
     * Should this game launch in app by default?
     */
    _shouldLaunchInApp(gameId, global) {
        // Only launch in app if:
        // 1. User is on mobile
        // 2. Game has app support
        // 3. User plays in app (not browser)
        const hasApp = SmartLauncher.hasAppSupport(gameId);
        const onMobile = ['ios', 'android'].includes(global.mobileOS);
        const playsInApp = ['nyt-ios', 'nyt-android'].includes(global.trackingSource);
        
        return hasApp && onMobile && playsInApp;
    },
    
    _loadData() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            return data ? JSON.parse(data) : {};
        } catch (e) {
            return {};
        }
    },
    
    _saveData(data) {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.error('Failed to save tracking preferences:', e);
        }
    }
};

// ============================================================================
// CSS STYLES FOR ONBOARDING
// ============================================================================

const OnboardingStyles = `
<style id="onboarding-styles">
    .onboarding-modal {
        max-width: 440px;
        margin: 0 auto;
    }
    
    .onboarding-progress {
        height: 4px;
        background: var(--bg-hover);
        border-radius: 2px;
        margin-bottom: 30px;
        overflow: hidden;
    }
    
    .onboarding-progress-bar {
        height: 100%;
        background: var(--accent-gold);
        transition: width 0.3s ease;
    }
    
    .onboarding-step {
        text-align: center;
    }
    
    .onboarding-icon {
        font-size: 4rem;
        margin-bottom: 15px;
    }
    
    .onboarding-step h2 {
        font-size: 1.5rem;
        margin-bottom: 8px;
        color: var(--text-primary);
    }
    
    .onboarding-subtitle {
        color: var(--text-secondary);
        margin-bottom: 25px;
    }
    
    .onboarding-description {
        color: var(--text-muted);
        margin-bottom: 30px;
        line-height: 1.5;
    }
    
    .onboarding-detected {
        margin-bottom: 25px;
    }
    
    .detected-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 20px;
        background: var(--bg-secondary);
        border-radius: 25px;
        font-size: 0.9rem;
    }
    
    .detected-icon {
        font-size: 1.2rem;
    }
    
    .onboarding-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-top: 25px;
    }
    
    .btn-large {
        padding: 15px 30px;
        font-size: 1.1rem;
    }
    
    .btn-text {
        background: none;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        padding: 10px;
        font-size: 0.9rem;
    }
    
    .btn-text:hover {
        color: var(--text-secondary);
    }
    
    /* Platform Options */
    .platform-options {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin: 20px 0;
    }
    
    .platform-option {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px;
        background: var(--bg-secondary);
        border: 2px solid transparent;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .platform-option:hover {
        background: var(--bg-hover);
    }
    
    .platform-option.selected {
        border-color: var(--accent-gold);
        background: var(--bg-hover);
    }
    
    .platform-option input {
        display: none;
    }
    
    .platform-icon {
        font-size: 1.5rem;
    }
    
    .platform-label {
        flex: 1;
        text-align: left;
        font-weight: 600;
    }
    
    .platform-check {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background: var(--accent-gold);
        color: #000;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        opacity: 0;
        transform: scale(0.8);
        transition: all 0.2s;
    }
    
    .platform-option.selected .platform-check {
        opacity: 1;
        transform: scale(1);
    }
    
    /* Extension Promo */
    .extension-promo {
        background: var(--bg-secondary);
        border-radius: 16px;
        padding: 20px;
        margin: 20px 0;
    }
    
    .extension-preview img {
        width: 100%;
        border-radius: 8px;
        margin-bottom: 15px;
    }
    
    .extension-benefits {
        text-align: left;
    }
    
    .benefit-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 0;
        font-size: 0.9rem;
    }
    
    .benefit-icon {
        font-size: 1.2rem;
    }
    
    /* Capture Methods */
    .capture-methods {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin: 20px 0;
    }
    
    .capture-method {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px;
        background: var(--bg-secondary);
        border-radius: 12px;
        cursor: pointer;
        position: relative;
        transition: all 0.2s;
    }
    
    .capture-method:hover {
        background: var(--bg-hover);
    }
    
    .capture-method.recommended {
        border: 2px solid var(--accent-gold);
    }
    
    .recommended-badge {
        position: absolute;
        top: -8px;
        right: 15px;
        background: var(--accent-gold);
        color: #000;
        font-size: 0.7rem;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 4px;
        text-transform: uppercase;
    }
    
    .method-icon {
        font-size: 1.8rem;
    }
    
    .method-info {
        text-align: left;
    }
    
    .method-title {
        font-weight: 700;
        margin-bottom: 4px;
    }
    
    .method-desc {
        font-size: 0.85rem;
        color: var(--text-muted);
    }
    
    /* Setup Steps */
    .setup-steps {
        text-align: left;
        margin: 25px 0;
    }
    
    .setup-step {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        padding: 12px 0;
    }
    
    .step-number {
        width: 28px;
        height: 28px;
        background: var(--accent-gold);
        color: #000;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        flex-shrink: 0;
    }
    
    .step-text {
        padding-top: 3px;
        line-height: 1.4;
    }
</style>
`;

// ============================================================================
// EXPORTS
// ============================================================================

if (typeof window !== 'undefined') {
    window.PlatformDetector = PlatformDetector;
    window.DeepLinks = DeepLinks;
    window.SmartLauncher = SmartLauncher;
    window.OnboardingFlow = OnboardingFlow;
    window.OnboardingStyles = OnboardingStyles;
    window.TrackingPreferences = TrackingPreferences;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        PlatformDetector,
        DeepLinks,
        SmartLauncher,
        OnboardingFlow,
        OnboardingStyles,
        TrackingPreferences
    };
}
