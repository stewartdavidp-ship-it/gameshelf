# Contributing to Game Shelf

Thank you for your interest in contributing to Game Shelf! This document provides guidelines for contributing to the project.

---

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How to Contribute](#how-to-contribute)
- [Development Setup](#development-setup)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Documentation](#documentation)

---

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

---

## How to Contribute

### Reporting Bugs

1. **Check existing issues** to avoid duplicates
2. **Create a detailed bug report** including:
   - Clear description of the issue
   - Steps to reproduce
   - Expected vs actual behavior
   - Browser/device information
   - Screenshots if applicable

### Suggesting Features

1. **Check if already planned** in [FEATURES.md](./docs/FEATURES.md)
2. **Create a feature request** including:
   - Clear description of the feature
   - Use case / why it's valuable
   - Any mockups or examples
   - Implementation considerations

### Making Changes

1. **Discuss first** for major changes
2. **Fork the repository**
3. **Create a feature branch**
4. **Make your changes**
5. **Test thoroughly**
6. **Submit a pull request**

---

## Development Setup

### Prerequisites

- Modern web browser (Chrome, Firefox, Safari, Edge)
- Text editor (VS Code recommended)
- Git
- Optional: Node.js (for future build tools)

### Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/gameshelf.git
   cd gameshelf
   ```

2. **Open in browser**
   ```bash
   # Simply open the HTML file
   open gameshelf.html
   # Or use a local server
   python -m http.server 8000
   ```

3. **Make changes and refresh browser**

### Firebase Setup (Optional)

For full functionality with cloud sync:

1. Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Enable Authentication (Google provider)
3. Enable Realtime Database
4. Copy your config to `firebaseConfig` in gameshelf.html

---

## Pull Request Process

### Before Submitting

- [ ] Code follows project style guidelines
- [ ] Self-reviewed the changes
- [ ] Added/updated relevant documentation
- [ ] Updated CHANGELOG.md under `[Unreleased]`
- [ ] Tested in multiple browsers
- [ ] No console errors or warnings
- [ ] Existing functionality still works

### PR Title Format

```
type(scope): brief description
```

Examples:
- `feat(merch): add gift category filtering`
- `fix(wallet): correct streak bonus calculation`
- `docs: update API integration guide`

### PR Description Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactoring
- [ ] Performance improvement

## Testing
Describe testing performed

## Screenshots
If applicable

## Checklist
- [ ] Tested in Chrome
- [ ] Tested in Safari
- [ ] Tested on mobile
- [ ] Updated CHANGELOG.md
- [ ] No console errors
```

### Review Process

1. Automated checks run (if configured)
2. Code review by maintainer
3. Requested changes addressed
4. Approval and merge

---

## Coding Standards

### JavaScript

#### Naming Conventions

```javascript
// Variables and functions: camelCase
let userName = 'Dave';
function calculateScore() { }

// Constants: UPPER_SNAKE_CASE
const MAX_STREAK_BONUS = 200;
const FEATURED_GAMES = [];

// Private/internal: leading underscore (optional)
function _internalHelper() { }
```

#### Functions

```javascript
// Prefer arrow functions for callbacks
items.map(item => item.name);

// Use regular functions for methods that need 'this'
function showModal() {
    this.classList.add('active');
}

// Add JSDoc for complex functions
/**
 * Calculate battle score based on game results
 * @param {string} gameId - The game identifier
 * @param {number} result - Raw game result
 * @returns {number} Normalized score (0-6)
 */
function calculateBattleScore(gameId, result) {
    // ...
}
```

#### Error Handling

```javascript
// Always handle potential errors
try {
    const data = await fetchData();
    processData(data);
} catch (error) {
    console.error('Failed to fetch data:', error);
    showToast('Something went wrong. Please try again.');
}

// Validate inputs
function earnCoins(amount, reason) {
    if (typeof amount !== 'number' || amount <= 0) {
        console.error('Invalid coin amount:', amount);
        return;
    }
    // ...
}
```

### CSS

#### Organization

```css
/* Group by component */
/* === Header === */
.header { }
.header-content { }

/* === Navigation === */
.nav-tabs { }
.nav-tab { }

/* === Modals === */
.modal-overlay { }
.modal { }
```

#### Use CSS Variables

```css
/* Define in :root */
:root {
    --bg-primary: #1a1a2e;
    --accent-gold: #f4d35e;
}

/* Use throughout */
.card {
    background: var(--bg-primary);
    border-color: var(--accent-gold);
}
```

#### Responsive Design

```css
/* Mobile-first approach */
.container {
    padding: 10px;
}

/* Tablet and up */
@media (min-width: 768px) {
    .container {
        padding: 20px;
    }
}

/* Desktop */
@media (min-width: 1024px) {
    .container {
        max-width: 900px;
        margin: 0 auto;
    }
}
```

### HTML

#### Semantic Structure

```html
<!-- Use semantic elements -->
<header class="header">
    <nav class="nav-tabs">...</nav>
</header>

<main class="container">
    <section class="games-section">...</section>
</main>

<footer class="footer">...</footer>
```

#### Accessibility

```html
<!-- Include aria labels -->
<button aria-label="Open menu" onclick="toggleMenu()">☰</button>

<!-- Use alt text for images -->
<img src="avatar.png" alt="User profile picture">

<!-- Label form inputs -->
<label for="battle-name">Battle Name</label>
<input id="battle-name" type="text">
```

---

## Commit Guidelines

### Format

```
type(scope): subject

body (optional)

footer (optional)
```

### Types

| Type | Description |
|------|-------------|
| `feat` | New feature |
| `fix` | Bug fix |
| `docs` | Documentation only |
| `style` | Formatting, whitespace |
| `refactor` | Code change that neither fixes nor adds |
| `perf` | Performance improvement |
| `test` | Adding/updating tests |
| `chore` | Maintenance, dependencies |

### Scopes

| Scope | Description |
|-------|-------------|
| `games` | Game tracking functionality |
| `wallet` | Coins/economy system |
| `battle` | Brain Battles feature |
| `merch` | Merch store |
| `social` | Friends, leaderboards |
| `auth` | Authentication |
| `ui` | General UI changes |

### Examples

```bash
# Feature
feat(merch): add Goody gift tier browsing modal

# Bug fix
fix(wallet): prevent negative coin balance

# Documentation
docs: add Goody API integration examples

# Refactoring
refactor(battle): extract scoring logic to separate function

# Multiple scopes
feat(wallet,merch): add coin purchase flow
```

### Good Commit Messages

✅ `feat(merch): add category filtering for gift tiers`
✅ `fix(battle): resolve score sync issue in group competitions`
✅ `docs: update README with deployment instructions`

### Poor Commit Messages

❌ `fixed stuff`
❌ `WIP`
❌ `changes`
❌ `update`

---

## Documentation

### When to Update Docs

- **README.md**: Project overview, setup instructions change
- **CHANGELOG.md**: Every feature, fix, or notable change
- **ARCHITECTURE.md**: Structural or design changes
- **FEATURES.md**: Feature status changes
- **API-INTEGRATION.md**: API usage changes

### CHANGELOG Format

```markdown
## [Unreleased]

### Added
- New feature description

### Changed
- Change description

### Fixed
- Bug fix description

### Removed
- Removed feature description
```

### Code Comments

```javascript
// Good: Explains WHY
// Skip weekends for streak calculation (users expect M-F only)
if (isWeekend(date)) continue;

// Bad: Explains WHAT (obvious from code)
// Loop through the array
for (let i = 0; i < arr.length; i++) {
```

---

## Questions?

If you have questions about contributing:
1. Check existing documentation
2. Look at recent commits for examples
3. Open a discussion/issue

Thank you for contributing to Game Shelf! 🎮
