/**
 * GAME SHELF - Partner Framework Module
 * Version: 1.0.0
 * 
 * Manages game placements across different tiers:
 * - Featured Games (RB Games rotation)
 * - Sponsored Placements (paid advertising)
 * - Indie API Partners (data exchange)
 * - Discovery/Recommendations
 * 
 * REVENUE MODEL:
 * - Sponsored Spots: Paid placement in premium positions
 * - API Partners: Free placement in exchange for result data API access
 * - Discovery: Editorial/algorithmic recommendations
 */

// ============================================================================
// PLACEMENT TYPES & CONFIGURATION
// ============================================================================

const PlacementType = {
    // Premium top-of-page slot - your games or highest-paying sponsors
    FEATURED: 'featured',
    
    // Clearly labeled paid placement
    SPONSORED: 'sponsored',
    
    // Indie games that provide API access for results
    API_PARTNER: 'api_partner',
    
    // Editorial picks / algorithmic recommendations
    DISCOVERY: 'discovery',
    
    // Standard game directory listing
    CATALOG: 'catalog'
};

const PlacementConfig = {
    [PlacementType.FEATURED]: {
        maxSlots: 4,
        label: null, // No label - this is prime real estate
        position: 'hero',
        rotationDays: 7, // Rotate weekly
        priority: 100
    },
    [PlacementType.SPONSORED]: {
        maxSlots: 2,
        label: 'Sponsored',
        labelStyle: 'badge',
        position: 'above-featured',
        trackClicks: true,
        trackImpressions: true,
        priority: 90
    },
    [PlacementType.API_PARTNER]: {
        maxSlots: 6,
        label: 'Partner Game',
        labelStyle: 'subtle',
        position: 'featured-rotation',
        benefits: ['result-api', 'analytics-dashboard', 'contest-integration'],
        priority: 70
    },
    [PlacementType.DISCOVERY]: {
        maxSlots: 8,
        label: 'Discover',
        position: 'below-my-games',
        algorithm: 'collaborative-filtering',
        priority: 50
    },
    [PlacementType.CATALOG]: {
        maxSlots: null, // Unlimited
        label: null,
        position: 'browse-all',
        priority: 10
    }
};

// ============================================================================
// PARTNER DATA SCHEMA
// ============================================================================

/**
 * Partner/Game registration schema
 * @typedef {Object} GamePartner
 * @property {string} id - Unique identifier
 * @property {string} name - Display name
 * @property {string} icon - Emoji icon
 * @property {string} url - Game URL
 * @property {string} description - Short description
 * @property {string} source - Publisher (e.g., 'indie', 'nyt', 'latimes')
 * @property {string} placementType - One of PlacementType values
 * @property {Object} contract - Partnership terms
 * @property {Object} api - API integration details (for partners)
 * @property {Object} analytics - Tracking data
 * @property {string[]} tags - Categorization tags
 * @property {boolean} active - Currently showing
 * @property {Date} startDate - Placement start
 * @property {Date} endDate - Placement end (null = indefinite)
 */

// ============================================================================
// INDIE PARTNER API SCHEMA
// ============================================================================

/**
 * API integration specification for indie partners
 * Games that integrate with this schema get placement benefits
 */
const IndieAPISpec = {
    version: '1.0',
    
    // What we need from the partner
    endpoints: {
        // GET results for a user (by our user token)
        getResults: {
            method: 'GET',
            path: '/api/gameshelf/results',
            params: {
                userToken: 'string', // Our anonymized user identifier
                date: 'string', // YYYY-MM-DD, optional
                limit: 'number' // Max results to return
            },
            response: {
                puzzleNumber: 'string',
                date: 'string',
                score: 'string', // Display score
                success: 'boolean',
                perfect: 'boolean',
                raw: 'object', // Game-specific data
                timestamp: 'string' // ISO date
            }
        },
        
        // Verify user has played (lightweight check)
        verifyPlay: {
            method: 'GET',
            path: '/api/gameshelf/verify',
            params: {
                userToken: 'string',
                puzzleNumber: 'string'
            },
            response: {
                played: 'boolean',
                timestamp: 'string'
            }
        },
        
        // Optional: Push notification when user completes
        webhookUrl: {
            description: 'We can provide a webhook URL for real-time notifications',
            payload: {
                event: 'game_complete',
                userToken: 'string',
                puzzleNumber: 'string',
                timestamp: 'string'
            }
        }
    },
    
    // What we provide to partners
    partnerBenefits: {
        placement: {
            type: PlacementType.API_PARTNER,
            duration: '90_days_renewable',
            position: 'featured_rotation'
        },
        analytics: {
            dailyActiveUsers: true,
            clickThroughRate: true,
            userDemographics: 'aggregated', // Never individual
            competitionEngagement: true
        },
        contestIntegration: {
            createContests: true,
            crossGameLeaderboards: true,
            prizeSupport: 'future_feature'
        },
        trafficReferrals: {
            deepLinks: true,
            utmTracking: true,
            referralDashboard: true
        }
    },
    
    // Authentication
    auth: {
        type: 'api_key',
        header: 'X-GameShelf-Partner-Key',
        userTokenFormat: 'gs_user_{hash}' // Anonymized, not email/name
    }
};

// ============================================================================
// PARTNER MANAGER CLASS
// ============================================================================

class PartnerManager {
    constructor(storageKey = 'gameshelf_partners') {
        this.storageKey = storageKey;
        this.partners = this._loadPartners();
        this.placements = this._computePlacements();
    }
    
    // -------------------------------------------------------------------------
    // STORAGE
    // -------------------------------------------------------------------------
    
    _loadPartners() {
        if (typeof localStorage !== 'undefined') {
            const data = localStorage.getItem(this.storageKey);
            if (data) {
                try {
                    return JSON.parse(data);
                } catch (e) {
                    console.error('Failed to load partners:', e);
                }
            }
        }
        return this._getDefaultPartners();
    }
    
    _savePartners() {
        if (typeof localStorage !== 'undefined') {
            localStorage.setItem(this.storageKey, JSON.stringify(this.partners));
        }
    }
    
    _getDefaultPartners() {
        // Default RB Games as featured
        return {
            'rungs': {
                id: 'rungs',
                name: 'Rungs',
                icon: '🪜',
                url: 'https://stewartdavidp-ship-it.github.io/Rungstest/',
                description: 'Pair words and arrange in order',
                source: 'rb-games',
                placementType: PlacementType.FEATURED,
                contract: { type: 'internal', revenue_share: 100 },
                api: null,
                analytics: { clicks: 0, impressions: 0, plays: 0 },
                tags: ['word', 'puzzle', 'daily'],
                active: true,
                startDate: new Date('2025-01-01'),
                endDate: null
            },
            'slate': {
                id: 'slate',
                name: 'Slate',
                icon: '🪨',
                url: 'https://stewartdavidp-ship-it.github.io/Slate/',
                description: 'Fill in consonants to reveal words',
                source: 'rb-games',
                placementType: PlacementType.FEATURED,
                contract: { type: 'internal', revenue_share: 100 },
                api: null,
                analytics: { clicks: 0, impressions: 0, plays: 0 },
                tags: ['word', 'puzzle', 'daily'],
                active: true,
                startDate: new Date('2025-01-01'),
                endDate: null
            },
            'quotle': {
                id: 'quotle',
                name: 'Quotle',
                icon: '💬',
                url: 'https://stewartdavidp-ship-it.github.io/Quotle/',
                description: 'Guess the famous quote',
                source: 'rb-games',
                placementType: PlacementType.FEATURED,
                contract: { type: 'internal', revenue_share: 100 },
                api: null,
                analytics: { clicks: 0, impressions: 0, plays: 0 },
                tags: ['word', 'trivia', 'daily'],
                active: true,
                startDate: new Date('2025-01-01'),
                endDate: null
            },
            'wordboxing': {
                id: 'wordboxing',
                name: 'Word Boxing',
                icon: '🥊',
                url: 'https://stewartdavidp-ship-it.github.io/WordBoxing/',
                description: 'Multiplayer word battle',
                source: 'rb-games',
                placementType: PlacementType.FEATURED,
                contract: { type: 'internal', revenue_share: 100 },
                api: null,
                analytics: { clicks: 0, impressions: 0, plays: 0 },
                tags: ['word', 'multiplayer', 'pvp'],
                active: true,
                startDate: new Date('2025-01-01'),
                endDate: null
            }
        };
    }
    
    // -------------------------------------------------------------------------
    // PLACEMENT COMPUTATION
    // -------------------------------------------------------------------------
    
    _computePlacements() {
        const placements = {
            [PlacementType.FEATURED]: [],
            [PlacementType.SPONSORED]: [],
            [PlacementType.API_PARTNER]: [],
            [PlacementType.DISCOVERY]: [],
            [PlacementType.CATALOG]: []
        };
        
        const now = new Date();
        
        for (const partner of Object.values(this.partners)) {
            // Check if placement is active
            if (!partner.active) continue;
            if (partner.endDate && new Date(partner.endDate) < now) continue;
            if (partner.startDate && new Date(partner.startDate) > now) continue;
            
            const type = partner.placementType || PlacementType.CATALOG;
            const config = PlacementConfig[type];
            
            // Check slot limits
            if (config.maxSlots && placements[type].length >= config.maxSlots) {
                // Move to next lower tier
                placements[PlacementType.CATALOG].push(partner);
            } else {
                placements[type].push(partner);
            }
        }
        
        // Sort each category by priority (if defined in partner) or alphabetically
        for (const type of Object.keys(placements)) {
            placements[type].sort((a, b) => {
                if (a.priority !== undefined && b.priority !== undefined) {
                    return b.priority - a.priority;
                }
                return a.name.localeCompare(b.name);
            });
        }
        
        return placements;
    }
    
    // -------------------------------------------------------------------------
    // PUBLIC API
    // -------------------------------------------------------------------------
    
    /**
     * Get games for a specific placement type
     * @param {string} type - PlacementType value
     * @returns {Array} - List of partner objects
     */
    getPlacement(type) {
        return this.placements[type] || [];
    }
    
    /**
     * Get all active placements organized by position
     * @returns {Object} - { featured: [], sponsored: [], ... }
     */
    getAllPlacements() {
        return { ...this.placements };
    }
    
    /**
     * Get featured games (for hero section)
     * @returns {Array}
     */
    getFeaturedGames() {
        return this.placements[PlacementType.FEATURED];
    }
    
    /**
     * Get sponsored placements (with tracking)
     * @returns {Array}
     */
    getSponsoredGames() {
        return this.placements[PlacementType.SPONSORED].map(game => ({
            ...game,
            _isSponsored: true,
            _label: PlacementConfig[PlacementType.SPONSORED].label
        }));
    }
    
    /**
     * Get API partner games
     * @returns {Array}
     */
    getAPIPartners() {
        return this.placements[PlacementType.API_PARTNER];
    }
    
    /**
     * Register a new partner
     * @param {GamePartner} partner 
     */
    registerPartner(partner) {
        if (!partner.id) {
            partner.id = this._generateId(partner.name);
        }
        
        // Set defaults
        partner.analytics = partner.analytics || { clicks: 0, impressions: 0, plays: 0 };
        partner.active = partner.active !== false;
        partner.startDate = partner.startDate || new Date();
        partner.tags = partner.tags || [];
        
        this.partners[partner.id] = partner;
        this._savePartners();
        this.placements = this._computePlacements();
        
        return partner;
    }
    
    /**
     * Update partner details
     * @param {string} id 
     * @param {Object} updates 
     */
    updatePartner(id, updates) {
        if (!this.partners[id]) {
            throw new Error(`Partner not found: ${id}`);
        }
        
        this.partners[id] = { ...this.partners[id], ...updates };
        this._savePartners();
        this.placements = this._computePlacements();
        
        return this.partners[id];
    }
    
    /**
     * Remove a partner
     * @param {string} id 
     */
    removePartner(id) {
        delete this.partners[id];
        this._savePartners();
        this.placements = this._computePlacements();
    }
    
    /**
     * Track impression for analytics
     * @param {string} id 
     */
    trackImpression(id) {
        if (this.partners[id]) {
            this.partners[id].analytics.impressions++;
            this._savePartners();
        }
    }
    
    /**
     * Track click for analytics
     * @param {string} id 
     */
    trackClick(id) {
        if (this.partners[id]) {
            this.partners[id].analytics.clicks++;
            this._savePartners();
        }
    }
    
    /**
     * Track play completion for analytics
     * @param {string} id 
     */
    trackPlay(id) {
        if (this.partners[id]) {
            this.partners[id].analytics.plays++;
            this._savePartners();
        }
    }
    
    /**
     * Get analytics for a partner
     * @param {string} id 
     * @returns {Object}
     */
    getAnalytics(id) {
        const partner = this.partners[id];
        if (!partner) return null;
        
        const analytics = partner.analytics;
        return {
            ...analytics,
            ctr: analytics.impressions > 0 
                ? (analytics.clicks / analytics.impressions * 100).toFixed(2) + '%'
                : 'N/A',
            conversionRate: analytics.clicks > 0
                ? (analytics.plays / analytics.clicks * 100).toFixed(2) + '%'
                : 'N/A'
        };
    }
    
    /**
     * Get all analytics (for admin dashboard)
     * @returns {Object}
     */
    getAllAnalytics() {
        const results = {};
        for (const [id, partner] of Object.entries(this.partners)) {
            results[id] = this.getAnalytics(id);
        }
        return results;
    }
    
    // -------------------------------------------------------------------------
    // INDIE PARTNER API HELPERS
    // -------------------------------------------------------------------------
    
    /**
     * Register an indie game as API partner
     * @param {Object} gameInfo - Basic game info
     * @param {Object} apiConfig - API endpoint configuration
     * @returns {Object} - Partner record with API key
     */
    registerIndiePartner(gameInfo, apiConfig) {
        const partner = {
            ...gameInfo,
            placementType: PlacementType.API_PARTNER,
            source: 'indie',
            contract: {
                type: 'api_exchange',
                benefits: IndieAPISpec.partnerBenefits,
                dataAccess: ['results', 'verify']
            },
            api: {
                ...apiConfig,
                key: this._generateAPIKey(),
                verified: false,
                lastSync: null,
                syncErrors: []
            }
        };
        
        return this.registerPartner(partner);
    }
    
    /**
     * Verify API partner integration is working
     * @param {string} partnerId 
     * @returns {Promise<boolean>}
     */
    async verifyPartnerAPI(partnerId) {
        const partner = this.partners[partnerId];
        if (!partner || !partner.api) {
            throw new Error('Partner not found or not an API partner');
        }
        
        try {
            // Try to fetch from their verify endpoint
            const response = await fetch(partner.api.baseUrl + IndieAPISpec.endpoints.verifyPlay.path, {
                method: 'GET',
                headers: {
                    'X-GameShelf-Partner-Key': partner.api.key
                }
            });
            
            if (response.ok) {
                this.updatePartner(partnerId, {
                    api: { ...partner.api, verified: true, lastSync: new Date() }
                });
                return true;
            }
        } catch (e) {
            this.partners[partnerId].api.syncErrors.push({
                timestamp: new Date(),
                error: e.message
            });
            this._savePartners();
        }
        
        return false;
    }
    
    /**
     * Get API specification for indie partners
     * @returns {Object}
     */
    getAPISpec() {
        return IndieAPISpec;
    }
    
    /**
     * Generate API documentation for partners
     * @returns {string} - Markdown documentation
     */
    generateAPIDocumentation() {
        return `
# Game Shelf API Partner Integration

## Overview
Integrate your game with Game Shelf to get featured placement in exchange for result data API access.

## Benefits
- Featured placement in the "Partner Games" section
- Analytics dashboard with CTR, impressions, and plays
- Contest/competition integration
- Traffic referrals with UTM tracking

## API Requirements

### Authentication
Include your API key in the \`X-GameShelf-Partner-Key\` header.

### Endpoints to Implement

#### GET /api/gameshelf/results
Return user's game results.

**Parameters:**
- \`userToken\` (string): Our anonymized user identifier
- \`date\` (string, optional): YYYY-MM-DD format
- \`limit\` (number, optional): Max results to return

**Response:**
\`\`\`json
{
  "puzzleNumber": "123",
  "date": "2025-01-14",
  "score": "4/6",
  "success": true,
  "perfect": false,
  "raw": { "guesses": 4, "time": 45 },
  "timestamp": "2025-01-14T12:00:00Z"
}
\`\`\`

#### GET /api/gameshelf/verify
Verify a user has played a specific puzzle.

**Parameters:**
- \`userToken\` (string): User identifier
- \`puzzleNumber\` (string): Puzzle to verify

**Response:**
\`\`\`json
{
  "played": true,
  "timestamp": "2025-01-14T12:00:00Z"
}
\`\`\`

## User Privacy
- We never share email addresses or personal information
- User tokens are anonymized hashes
- Partners only see aggregated analytics

## Getting Started
1. Contact us at partners@gameshelf.app
2. Implement the required endpoints
3. We verify integration and activate placement

`;
    }
    
    // -------------------------------------------------------------------------
    // SPONSORED PLACEMENT HELPERS
    // -------------------------------------------------------------------------
    
    /**
     * Create a sponsored placement campaign
     * @param {Object} campaign 
     * @returns {Object}
     */
    createSponsoredCampaign(campaign) {
        const sponsor = {
            ...campaign.gameInfo,
            placementType: PlacementType.SPONSORED,
            contract: {
                type: 'sponsored',
                budget: campaign.budget,
                cpm: campaign.cpm || 5.00, // $5 CPM default
                dailyBudget: campaign.dailyBudget || campaign.budget / 30,
                startDate: campaign.startDate,
                endDate: campaign.endDate
            },
            analytics: {
                clicks: 0,
                impressions: 0,
                plays: 0,
                spend: 0
            },
            active: true,
            startDate: campaign.startDate || new Date(),
            endDate: campaign.endDate
        };
        
        return this.registerPartner(sponsor);
    }
    
    /**
     * Calculate remaining budget for sponsor
     * @param {string} id 
     * @returns {Object}
     */
    getSponsorBudgetStatus(id) {
        const partner = this.partners[id];
        if (!partner || partner.placementType !== PlacementType.SPONSORED) {
            return null;
        }
        
        const spent = (partner.analytics.impressions / 1000) * partner.contract.cpm;
        const remaining = partner.contract.budget - spent;
        
        return {
            budget: partner.contract.budget,
            spent: spent.toFixed(2),
            remaining: remaining.toFixed(2),
            impressions: partner.analytics.impressions,
            daysRemaining: Math.ceil(remaining / partner.contract.dailyBudget),
            exhausted: remaining <= 0
        };
    }
    
    // -------------------------------------------------------------------------
    // DISCOVERY / RECOMMENDATIONS
    // -------------------------------------------------------------------------
    
    /**
     * Get personalized game recommendations
     * @param {Object} userProfile - User's play history and preferences
     * @returns {Array}
     */
    getRecommendations(userProfile) {
        const recommendations = [];
        const playedGames = new Set(userProfile.playedGames || []);
        const preferredTags = userProfile.preferredTags || [];
        
        // Get all catalog games not yet played
        const candidates = Object.values(this.partners).filter(p => 
            !playedGames.has(p.id) && p.active
        );
        
        // Score each candidate
        for (const game of candidates) {
            let score = 0;
            
            // Tag matching
            const matchingTags = game.tags.filter(t => preferredTags.includes(t));
            score += matchingTags.length * 10;
            
            // Popularity (based on analytics)
            if (game.analytics) {
                score += Math.log(game.analytics.plays + 1) * 5;
            }
            
            // Source bonus (prefer indie/partner games)
            if (game.source === 'indie' || game.placementType === PlacementType.API_PARTNER) {
                score += 15;
            }
            
            recommendations.push({ ...game, _recommendationScore: score });
        }
        
        // Sort by score and return top N
        return recommendations
            .sort((a, b) => b._recommendationScore - a._recommendationScore)
            .slice(0, PlacementConfig[PlacementType.DISCOVERY].maxSlots);
    }
    
    // -------------------------------------------------------------------------
    // UTILITY FUNCTIONS
    // -------------------------------------------------------------------------
    
    _generateId(name) {
        return name.toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
    }
    
    _generateAPIKey() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let key = 'gs_';
        for (let i = 0; i < 32; i++) {
            key += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return key;
    }
}

// ============================================================================
// CONTEST INTEGRATION
// ============================================================================

/**
 * Helper for creating cross-game contests with partner games
 */
const ContestIntegration = {
    /**
     * Create a multi-game contest
     * @param {Object} config 
     * @returns {Object}
     */
    createContest(config) {
        return {
            id: `contest_${Date.now()}`,
            name: config.name,
            description: config.description,
            games: config.games, // Array of game IDs
            startDate: config.startDate,
            endDate: config.endDate,
            scoringMethod: config.scoringMethod || 'total_points',
            rules: {
                // How to aggregate scores across games
                aggregation: config.aggregation || 'sum', // 'sum', 'average', 'best_n'
                // Minimum games required to qualify
                minGames: config.minGames || config.games.length,
                // Tiebreaker
                tiebreaker: config.tiebreaker || 'earliest_completion'
            },
            prizes: config.prizes || [],
            participants: [],
            leaderboard: []
        };
    },
    
    /**
     * Calculate contest score from parsed results
     * @param {Array} results - Array of NormalizedResult objects
     * @param {Object} contestRules 
     * @returns {number}
     */
    calculateScore(results, contestRules) {
        const points = results.map(r => r.contestPoints);
        
        switch (contestRules.aggregation) {
            case 'sum':
                return points.reduce((a, b) => a + b, 0);
            case 'average':
                return points.length > 0 
                    ? Math.round(points.reduce((a, b) => a + b, 0) / points.length)
                    : 0;
            case 'best_n':
                const sorted = [...points].sort((a, b) => b - a);
                const bestN = sorted.slice(0, contestRules.bestN || 3);
                return bestN.reduce((a, b) => a + b, 0);
            default:
                return points.reduce((a, b) => a + b, 0);
        }
    }
};

// ============================================================================
// EXPORTS
// ============================================================================

if (typeof window !== 'undefined') {
    window.PartnerManager = PartnerManager;
    window.PlacementType = PlacementType;
    window.PlacementConfig = PlacementConfig;
    window.IndieAPISpec = IndieAPISpec;
    window.ContestIntegration = ContestIntegration;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { 
        PartnerManager, 
        PlacementType, 
        PlacementConfig, 
        IndieAPISpec,
        ContestIntegration 
    };
}
